import React from "react";
import { Link } from "wouter";
import { ShoppingCart, User } from "lucide-react";

const Navbar: React.FC = () => {
  return (
    <nav className="bg-white shadow-md py-4">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/">
            <span className="font-bold text-xl text-gray-800 cursor-pointer">Logo</span>
          </Link>
        </div>

        <div className="hidden md:flex space-x-8">
          <Link href="/">
            <span className="text-gray-600 hover:text-gray-900 transition-colors cursor-pointer">Início</span>
          </Link>
          <Link href="/novidades">
            <span className="text-gray-600 hover:text-gray-900 transition-colors cursor-pointer">Novidades</span>
          </Link>
          <Link href="/sobre">
            <span className="text-gray-600 hover:text-gray-900 transition-colors cursor-pointer">Sobre</span>
          </Link>
          <Link href="/contato">
            <span className="text-gray-600 hover:text-gray-900 transition-colors cursor-pointer">Contato</span>
          </Link>
          <Link href="/login">
            <span className="text-gray-600 hover:text-gray-900 transition-colors cursor-pointer">Login</span>
          </Link>
          <Link href="/register">
            <span className="text-gray-600 hover:text-gray-900 transition-colors cursor-pointer">Registrar</span>
          </Link>
        </div>
        <div className="flex items-center space-x-4">
          <Link href="/cart">
            <span className="text-gray-600 hover:text-gray-900 cursor-pointer">
              <ShoppingCart className="h-6 w-6" />
            </span>
          </Link>
          <Link href="/admin">
            <span className="text-gray-600 hover:text-gray-900 cursor-pointer">
              <User className="h-6 w-6" />
            </span>
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;