import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Collection } from "@shared/schema";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";

export default function SpecialCollections() {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const { data: collections, isLoading } = useQuery<Collection[]>({
    queryKey: ["/api/collections"],
  });
  
  const nextSlide = () => {
    if (!collections) return;
    setCurrentSlide((prev) => (prev + 1) % collections.length);
  };
  
  const prevSlide = () => {
    if (!collections) return;
    setCurrentSlide((prev) => (prev - 1 + collections.length) % collections.length);
  };
  
  useEffect(() => {
    if (!collections || collections.length <= 1) return;
    
    const interval = setInterval(() => {
      nextSlide();
    }, 5000);
    
    return () => clearInterval(interval);
  }, [collections, currentSlide]);
  
  if (isLoading) {
    return (
      <section className="py-12 bg-gray-100">
        <div className="container mx-auto px-4">
          <Skeleton className="h-8 w-64 mb-8" />
          <Skeleton className="h-80 w-full rounded-xl" />
        </div>
      </section>
    );
  }
  
  return (
    <section className="py-12 bg-gray-100">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold font-sans text-black mb-8">
          Coleções Especiais
        </h2>
        
        <div className="bg-zinc-800 rounded-xl overflow-hidden">
          <div className="relative h-80">
            {collections?.map((collection, index) => (
              <div 
                key={collection.id}
                className={`absolute inset-0 transition-opacity duration-500 ${
                  index === currentSlide ? 'opacity-100' : 'opacity-0'
                }`}
              >
                <img 
                  src={collection.imageUrl} 
                  alt={collection.name} 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent flex items-center p-10">
                  <div className="max-w-md">
                    <h3 className="text-white text-3xl font-bold mb-4">{collection.name}</h3>
                    <p className="text-gray-200 mb-6">{collection.description}</p>
                    <Link href={`/colecoes/${collection.id}`} className="bg-[#4CAF50] text-white hover:bg-[#125C2F] py-2 px-6 rounded-md font-medium inline-block transition-colors">
                      Ver Coleção
                    </Link>
                  </div>
                </div>
              </div>
            ))}
            
            <div className="absolute bottom-4 right-4 flex space-x-2">
              <button 
                onClick={prevSlide}
                className="bg-black bg-opacity-50 hover:bg-opacity-70 text-white p-2 rounded-full transition-colors"
              >
                <ChevronLeft size={20} />
              </button>
              <button 
                onClick={nextSlide}
                className="bg-black bg-opacity-50 hover:bg-opacity-70 text-white p-2 rounded-full transition-colors"
              >
                <ChevronRight size={20} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
