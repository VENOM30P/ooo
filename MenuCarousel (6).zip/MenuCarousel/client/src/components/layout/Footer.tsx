import { Link } from "wouter";
import { 
  Facebook, 
  Instagram, 
  Twitter, 
  Youtube, 
  MapPin, 
  Phone, 
  Mail
} from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-gray-900 text-white pt-12 pb-6">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div>
            <h3 className="text-xl font-semibold mb-4">ONCE 11</h3>
            <p className="text-gray-400 mb-4">
              A sua loja esportiva com os melhores produtos para elevar sua performance.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-gray-400 hover:text-green-500 transition-colors">
                <Facebook className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-green-500 transition-colors">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-green-500 transition-colors">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-gray-400 hover:text-green-500 transition-colors">
                <Youtube className="h-5 w-5" />
              </a>
            </div>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-4">Categorias</h3>
            <ul className="space-y-2">
              <li><Link href="/calcados" className="text-gray-400 hover:text-white transition-colors">Calçados</Link></li>
              <li><Link href="/vestuario" className="text-gray-400 hover:text-white transition-colors">Vestuário</Link></li>
              <li><Link href="/acessorios" className="text-gray-400 hover:text-white transition-colors">Acessórios</Link></li>
              <li><Link href="/equipamentos" className="text-gray-400 hover:text-white transition-colors">Equipamentos</Link></li>
              <li><Link href="/nutricao" className="text-gray-400 hover:text-white transition-colors">Nutrição</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-4">Informações</h3>
            <ul className="space-y-2">
              <li><Link href="/sobre" className="text-gray-400 hover:text-white transition-colors">Sobre Nós</Link></li>
              <li><Link href="/privacidade" className="text-gray-400 hover:text-white transition-colors">Política de Privacidade</Link></li>
              <li><Link href="/termos" className="text-gray-400 hover:text-white transition-colors">Termos e Condições</Link></li>
              <li><Link href="/trocas" className="text-gray-400 hover:text-white transition-colors">Trocas e Devoluções</Link></li>
              <li><Link href="/faq" className="text-gray-400 hover:text-white transition-colors">FAQ</Link></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-xl font-semibold mb-4">Contato</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <MapPin className="h-5 w-5 mt-1 mr-2 text-green-500" />
                <span className="text-gray-400">Av. Paulista, 1000 - São Paulo, SP</span>
              </li>
              <li className="flex items-start">
                <Phone className="h-5 w-5 mt-1 mr-2 text-green-500" />
                <span className="text-gray-400">(11) 5555-5555</span>
              </li>
              <li className="flex items-start">
                <Mail className="h-5 w-5 mt-1 mr-2 text-green-500" />
                <span className="text-gray-400">contato@once11.com.br</span>
              </li>
            </ul>
          </div>
        </div>
        
        <div className="mt-12 pt-6 border-t border-gray-800 text-center text-gray-400 text-sm">
          <p>© {new Date().getFullYear()} ONCE 11. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
