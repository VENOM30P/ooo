import { useState } from "react";
import { Link, useLocation } from "wouter";
import { ShoppingCart, Search, User, Menu, LogOut } from "lucide-react";
import { useCart } from "@/hooks/useCart";
import { useAuth } from "@/hooks/useAuth";
import { ConnectionStatus } from "@/components/ui/connection-status";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { cartCount } = useCart();
  const { isAuthenticated, isAdmin, user, logout } = useAuth();
  const [, setLocation] = useLocation();

  const handleLogout = () => {
    logout();
    setLocation('/');
  };

  return (
    <nav className="bg-gray-900 text-white sticky top-0 z-50 shadow-md">
      <div className="container mx-auto px-4 py-3">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <Link href="/" className="flex items-center cursor-pointer">
            <span className="text-green-500 font-bold text-2xl">ONCE</span>
            <span className="text-white ml-1 font-bold text-2xl">11</span>
          </Link>

          {/* Menu Items - Desktop */}
          <div className="hidden md:flex items-center space-x-8">
            <NavigationMenu>
              <NavigationMenuList>
                <NavigationMenuItem>
                  <Link href="/" className="hover:text-green-500 transition-colors px-4 py-2">
                    Início
                  </Link>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <NavigationMenuTrigger className="bg-transparent text-white hover:text-green-500 hover:bg-transparent">
                    Produtos
                  </NavigationMenuTrigger>
                  <NavigationMenuContent>
                    <div className="grid gap-3 p-6 w-[400px] bg-white text-gray-900">
                      <div className="grid grid-cols-2 gap-4">
                        <Link href="/products" className="group">
                          <div className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-green-50">
                            <div className="text-green-600 font-medium leading-none">Todos os Produtos</div>
                            <p className="line-clamp-2 text-sm leading-snug text-gray-600">
                              Confira nossa coleção completa
                            </p>
                          </div>
                        </Link>
                        <Link href="/products?category=calcados" className="group">
                          <div className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-green-50">
                            <div className="text-green-600 font-medium leading-none">Calçados</div>
                            <p className="line-clamp-2 text-sm leading-snug text-gray-600">
                              Tênis e calçados esportivos
                            </p>
                          </div>
                        </Link>
                        <Link href="/products?category=camisetas" className="group">
                          <div className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-green-50">
                            <div className="text-green-600 font-medium leading-none">Camisetas</div>
                            <p className="line-clamp-2 text-sm leading-snug text-gray-600">
                              Camisetas de times e seleções
                            </p>
                          </div>
                        </Link>
                        <Link href="/products?category=acessorios" className="group">
                          <div className="block select-none space-y-1 rounded-md p-3 leading-none no-underline outline-none transition-colors hover:bg-green-50">
                            <div className="text-green-600 font-medium leading-none">Acessórios</div>
                            <p className="line-clamp-2 text-sm leading-snug text-gray-600">
                              Meias, bonés e mais
                            </p>
                          </div>
                        </Link>
                      </div>
                    </div>
                  </NavigationMenuContent>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <Link href="/novidades" className="hover:text-green-500 transition-colors px-4 py-2">
                    Novidades
                  </Link>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <Link href="/sobre" className="hover:text-green-500 transition-colors px-4 py-2">
                    Sobre
                  </Link>
                </NavigationMenuItem>

                <NavigationMenuItem>
                  <Link href="/contato" className="hover:text-green-500 transition-colors px-4 py-2">
                    Contato
                  </Link>
                </NavigationMenuItem>
              </NavigationMenuList>
            </NavigationMenu>
          </div>

          {/* Right Side Icons */}
          <div className="flex items-center space-x-6">
            <ConnectionStatus />
            
            <Link href="/search" className="hover:text-green-500 transition-colors">
              <Search className="h-5 w-5" />
            </Link>

            {isAuthenticated ? (
              <>
                {isAdmin && (
                  <Link href="/admin/dashboard" className="hover:text-green-500 transition-colors">
                    <User className="h-5 w-5" />
                  </Link>
                )}
                <button
                  onClick={handleLogout}
                  className="hover:text-green-500 transition-colors flex items-center space-x-2"
                >
                  <LogOut className="h-5 w-5" />
                  <span>Sair</span>
                </button>
              </>
            ) : (
              <Link href="/login" className="hover:text-green-500 transition-colors">
                <User className="h-5 w-5" />
              </Link>
            )}

            <Link href="/cart" className="hover:text-green-500 transition-colors relative">
              <ShoppingCart className="h-5 w-5" />
              <span className="absolute -top-2 -right-2 bg-green-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {cartCount}
              </span>
            </Link>

            <button 
              className="md:hidden focus:outline-none" 
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden">
          <div className="px-4 py-3 space-y-3 bg-gray-800">
            <div className="mb-2">
              <ConnectionStatus />
            </div>
            <Link href="/" className="block hover:text-green-500 transition-colors">Início</Link>
            <Link href="/products" className="block hover:text-green-500 transition-colors">Todos os Produtos</Link>
            <Link href="/products?category=calcados" className="block hover:text-green-500 transition-colors pl-4">Calçados</Link>
            <Link href="/products?category=camisetas" className="block hover:text-green-500 transition-colors pl-4">Camisetas</Link>
            <Link href="/products?category=acessorios" className="block hover:text-green-500 transition-colors pl-4">Acessórios</Link>
            <Link href="/novidades" className="block hover:text-green-500 transition-colors">Novidades</Link>
            <Link href="/sobre" className="block hover:text-green-500 transition-colors">Sobre</Link>
            <Link href="/contato" className="block hover:text-green-500 transition-colors">Contato</Link>

            {isAuthenticated ? (
              <>
                <span className="block text-green-500">Olá, {user?.username}</span>
                {isAdmin && (
                  <Link href="/admin/dashboard" className="block hover:text-green-500 transition-colors">
                    Painel Admin
                  </Link>
                )}
                <button
                  onClick={handleLogout}
                  className="block hover:text-green-500 transition-colors w-full text-left"
                >
                  Sair
                </button>
              </>
            ) : (
              <>
                <Link href="/login" className="block hover:text-green-500 transition-colors">
                  Login
                </Link>
                <Link href="/register" className="block hover:text-green-500 transition-colors">
                  Registrar
                </Link>
              </>
            )}

            <Link href="/cart" className="block hover:text-green-500 transition-colors">
              Carrinho ({cartCount})
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}