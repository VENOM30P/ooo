import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { MotivationalSlide } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";

export default function MotivationalSlider() {
  const [currentSlide, setCurrentSlide] = useState(0);
  
  const { data: slides, isLoading } = useQuery<MotivationalSlide[]>({
    queryKey: ["/api/motivational-slides"],
  });
  
  useEffect(() => {
    if (!slides || slides.length <= 1) return;
    
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    
    return () => clearInterval(interval);
  }, [slides]);
  
  if (isLoading) {
    return (
      <section className="py-12 bg-gray-100">
        <div className="container mx-auto px-4 max-w-5xl">
          <Skeleton className="h-8 w-64 mx-auto mb-8" />
          <Skeleton className="h-80 w-full rounded-xl" />
        </div>
      </section>
    );
  }
  
  return (
    <section className="py-12 bg-gray-100">
      <div className="container mx-auto px-4 max-w-5xl">
        <h2 className="text-3xl font-bold font-sans text-black text-center mb-8">
          Inspiração para Atletas
        </h2>
        
        <div className="relative overflow-hidden h-80 rounded-xl">
          <div 
            className="absolute inset-0 flex transition-transform duration-500 ease-in-out"
            style={{ transform: `translateX(-${currentSlide * 100}%)` }}
          >
            {slides?.map((slide, index) => (
              <div key={slide.id} className="w-full flex-shrink-0 relative">
                <img 
                  src={slide.imageUrl} 
                  alt="Inspiração atlética" 
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-transparent to-black/70 flex items-end justify-center pb-10">
                  <p className="text-white text-2xl md:text-3xl font-bold text-center max-w-2xl px-6">
                    "{slide.quote}"
                  </p>
                </div>
              </div>
            ))}
          </div>
          
          <div className="absolute bottom-4 left-0 right-0 flex justify-center space-x-2">
            {slides?.map((_, index) => (
              <button 
                key={index}
                className={`w-3 h-3 rounded-full bg-white ${
                  index === currentSlide ? 'opacity-100' : 'opacity-50'
                }`}
                onClick={() => setCurrentSlide(index)}
              />
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
