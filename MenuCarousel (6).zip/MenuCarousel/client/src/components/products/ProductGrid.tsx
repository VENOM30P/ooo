import { Product } from "@/lib/types";
import { ProductCard } from "@/components/ui/ProductCard";
import { useLayoutToggle } from "@/hooks/useLayoutToggle";
import { cn } from "@/lib/utils";

interface ProductGridProps {
  products?: Product[];
  isLoading?: boolean;
  title?: string;
}

export function ProductGrid({ products = [], isLoading, title }: ProductGridProps) {
  const { currentCategory } = useLayoutToggle();

  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {[...Array(8)].map((_, i) => (
          <div key={i} className="rounded-lg p-4 bg-white shadow animate-pulse">
            <div className="h-48 bg-gray-200 rounded-md mb-4"></div>
            <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
          </div>
        ))}
      </div>
    );
  }

  if (products.length === 0) {
    return (
      <div className="container mx-auto px-4 py-8 text-center">
        <p className="text-gray-500">Nenhum produto encontrado</p>
      </div>
    );
  }

  // Determinamos o layout baseado na categoria esportiva
  const getLayoutStyle = () => {
    switch(currentCategory) {
      case 'futebol':
        return {
          gridClass: "grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4",
          variant: "featured"
        };
      case 'basquete':
        return {
          gridClass: "grid-cols-1 md:grid-cols-2 lg:grid-cols-3",
          variant: "compact"
        };
      case 'volei':
        return {
          gridClass: "grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5",
          variant: "grid"
        };
      case 'tenis':
        return {
          gridClass: "grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6",
          variant: "grid"
        };
      default:
        return {
          gridClass: "grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4",
          variant: "featured"
        };
    }
  };

  const layoutStyle = getLayoutStyle();

  return (
    <div className="container mx-auto px-4 py-8">
      {title && (
        <h2 className="text-2xl font-bold mb-6 text-center">{title}</h2>
      )}

      <div 
        className={cn(
          "grid gap-6 transition-all duration-500 ease-in-out",
          layoutStyle.gridClass
        )}
      >
        {products.map((product) => (
          <ProductCard 
            key={product.id} 
            product={product} 
            variant={layoutStyle.variant as "featured" | "compact" | "grid"}
          />
        ))}
      </div>
    </div>
  );
}