import { Link } from "wouter";

export default function PromotionalBanner() {
  return (
    <section className="py-10 bg-zinc-900">
      <div className="container mx-auto px-4">
        <div className="banner-shape">
          <div className="flex flex-col md:flex-row items-center">
            <div className="p-8 md:w-1/2">
              <div className="inline-block bg-[#125C2F] text-white text-3xl font-bold px-6 py-3 rounded mb-4">
                50% OFF
              </div>
              <p className="text-white mb-6 max-w-lg">
                Aproveite nossa promoção especial na coleção BRAZUCA. Camisas oficiais da seleção brasileira com desconto imperdível por tempo limitado.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link href="/colecoes" className="bg-black border border-white text-white hover:bg-white hover:text-black py-2 px-6 rounded-md font-medium transition-colors">
                  Veja Outras Coleções
                </Link>
                <Link href="/colecoes/brazuca" className="bg-white text-black hover:bg-opacity-90 py-2 px-6 rounded-md font-medium transition-colors">
                  <span className="text-blue-700 font-bold">B</span>
                  <span className="text-yellow-500 font-bold">R</span>
                  <span className="text-[#4CAF50] font-bold">A</span>
                  <span className="text-yellow-500 font-bold">Z</span>
                  <span className="text-blue-700 font-bold">U</span>
                  <span className="text-[#4CAF50] font-bold">C</span>
                  <span className="text-yellow-500 font-bold">A</span>
                </Link>
              </div>
            </div>
            <div className="md:w-1/2 p-4 flex justify-center">
              <img 
                src="https://images.unsplash.com/photo-1616124619460-3485adb9af20?q=80&w=600&h=400&auto=format&fit=crop" 
                alt="Camisas da Seleção Brasileira" 
                className="rounded-lg max-h-80 object-contain"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
