import { useState, useRef, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight, Star, StarHalf } from "lucide-react";
import { Product } from "@shared/schema";
import { useCart } from "@/hooks/useCart";

export default function ProductCarousel() {
  const carouselRef = useRef<HTMLDivElement>(null);
  const [scrollPosition, setScrollPosition] = useState(0);
  const { addToCart } = useCart();
  
  const { data: featuredProducts, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products/featured"],
  });
  
  const scrollNext = () => {
    if (carouselRef.current) {
      const cardWidth = carouselRef.current.querySelector('.product-card')?.clientWidth || 0;
      const gap = 24; // 6 * 4px (gap-6)
      const nextPos = scrollPosition + cardWidth + gap;
      const maxScroll = carouselRef.current.scrollWidth - carouselRef.current.clientWidth;
      
      const newPos = Math.min(nextPos, maxScroll);
      setScrollPosition(newPos);
      carouselRef.current.scrollTo({
        left: newPos,
        behavior: "smooth"
      });
    }
  };
  
  const scrollPrev = () => {
    if (carouselRef.current) {
      const cardWidth = carouselRef.current.querySelector('.product-card')?.clientWidth || 0;
      const gap = 24; // 6 * 4px (gap-6)
      const prevPos = scrollPosition - (cardWidth + gap);
      
      const newPos = Math.max(prevPos, 0);
      setScrollPosition(newPos);
      carouselRef.current.scrollTo({
        left: newPos,
        behavior: "smooth"
      });
    }
  };
  
  return (
    <section className="py-12 bg-gray-100">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-bold font-sans text-black">Produtos em Destaque</h2>
          <div className="flex gap-2">
            <button 
              onClick={scrollPrev}
              className="p-2 rounded-full bg-gray-200 hover:bg-gray-300 transition"
            >
              <ChevronLeft className="text-black" />
            </button>
            <button 
              onClick={scrollNext}
              className="p-2 rounded-full bg-gray-200 hover:bg-gray-300 transition"
            >
              <ChevronRight className="text-black" />
            </button>
          </div>
        </div>
        
        <div className="relative overflow-hidden">
          <div 
            ref={carouselRef}
            className="flex gap-6 overflow-x-auto pb-4 snap-x scrollbar-hide"
            style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
          >
            {isLoading ? (
              // Skeleton Loading
              Array(5).fill(0).map((_, index) => (
                <div key={index} className="product-card flex-none w-full sm:w-1/2 md:w-1/3 lg:w-1/4 snap-start animate-pulse">
                  <div className="h-64 bg-gray-300"></div>
                  <div className="p-4">
                    <div className="h-5 bg-gray-300 rounded mb-2"></div>
                    <div className="h-12 bg-gray-200 rounded mb-3"></div>
                    <div className="h-6 bg-gray-300 rounded mb-3"></div>
                    <div className="h-10 bg-gray-300 rounded"></div>
                  </div>
                </div>
              ))
            ) : (
              featuredProducts?.map((product) => (
                <div key={product.id} className="product-card flex-none w-full sm:w-1/2 md:w-1/3 lg:w-1/4 snap-start">
                  <div className="relative h-64 overflow-hidden">
                    <img 
                      src={product.imageUrl} 
                      alt={product.name} 
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-0 left-0 p-3 bg-gradient-to-t from-black/70 to-transparent w-full">
                      <h3 className="text-white font-semibold text-lg">{product.name}</h3>
                    </div>
                  </div>
                  <div className="p-4">
                    <p className="text-gray-600 text-sm mb-2">{product.description}</p>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <span className="text-red-500 line-through text-sm">
                          R${product.originalPrice.toFixed(2).replace('.', ',')}
                        </span>
                        <span className="text-[#0A8043] font-bold text-xl">
                          R${product.currentPrice.toFixed(2).replace('.', ',')}
                        </span>
                      </div>
                      <div className="flex">
                        {[1, 2, 3, 4].map((star) => (
                          <Star key={star} size={16} className="text-yellow-500" fill="#F59E0B" />
                        ))}
                        <StarHalf size={16} className="text-yellow-500" fill="#F59E0B" />
                      </div>
                    </div>
                    <button 
                      className="add-to-cart-btn w-full py-2 text-white rounded-md font-medium"
                      onClick={() => addToCart(product)}
                    >
                      Adicionar ao Carrinho
                    </button>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
