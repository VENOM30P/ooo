import { useQuery } from "@tanstack/react-query";
import { Product } from "@shared/schema";
import { Skeleton } from "@/components/ui/skeleton";
import ProductCard from "@/components/ProductCard";

export default function TopSellingProducts() {
  const { data: topProducts, isLoading } = useQuery<Product[]>({
    queryKey: ["/api/products/top-selling"],
  });
  
  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold font-sans text-black mb-8">
          Produtos Mais Vendidos
        </h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {isLoading ? (
            // Skeleton Loading
            Array(8).fill(0).map((_, index) => (
              <div key={index} className="product-card animate-pulse">
                <div className="h-56 bg-gray-300"></div>
                <div className="p-4">
                  <Skeleton className="h-6 w-3/4 mb-1" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-4 w-full mb-2" />
                  <Skeleton className="h-5 w-1/2 mb-3" />
                  <Skeleton className="h-10 w-full" />
                </div>
              </div>
            ))
          ) : (
            topProducts?.map((product) => (
              <ProductCard 
                key={product.id} 
                product={product} 
                variant="top-selling" 
              />
            ))
          )}
        </div>
      </div>
    </section>
  );
}
