import { Product } from "@/lib/types";
import { useState } from "react";
import { Link } from "wouter";
import { useCart } from "@/hooks/useCart";
import { Button } from "./button";
import { cn } from "@/lib/utils";
import { motion } from "framer-motion";

interface ProductCardProps {
  product: Product;
  variant?: "featured" | "compact" | "grid";
}

export function ProductCard({ product, variant = "featured" }: ProductCardProps) {
  const [isLoading, setIsLoading] = useState(false);
  const { addToCart } = useCart();
  
  // Função para obter a cor baseada na categoria do produto
  const getCategoryColor = () => {
    switch(product.category.toLowerCase()) {
      case 'calcados':
        return 'text-blue-600';
      case 'camisetas':
        return 'text-purple-600';
      case 'acessorios':
        return 'text-amber-600';
      default:
        return 'text-green-600';
    }
  };
  
  // Função para obter a cor de hover baseada na categoria do produto
  const getCategoryHoverColor = () => {
    switch(product.category.toLowerCase()) {
      case 'calcados':
        return 'hover:text-blue-600';
      case 'camisetas':
        return 'hover:text-purple-600';
      case 'acessorios':
        return 'hover:text-amber-600';
      default:
        return 'hover:text-green-600';
    }
  };
  
  // Cores baseadas na categoria
  const priceColor = getCategoryColor();
  const hoverColor = getCategoryHoverColor();
  const buttonColor = product.category.toLowerCase() === 'calcados' ? 'bg-blue-600 hover:bg-blue-700' :
                    product.category.toLowerCase() === 'camisetas' ? 'bg-purple-600 hover:bg-purple-700' :
                    product.category.toLowerCase() === 'acessorios' ? 'bg-amber-600 hover:bg-amber-700' :
                    'bg-green-600 hover:bg-green-700';

  const handleAddToCart = async () => {
    try {
      setIsLoading(true);
      await addToCart(product);
    } catch (error) {
      console.error("Failed to add to cart:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // Layout grid - cartões pequenos e compactos
  if (variant === "grid") {
    return (
      <motion.div 
        className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-all"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2 }}
      >
        <Link href={`/product/${product.id}`}>
          <div className="cursor-pointer">
            <div className="h-32 overflow-hidden">
              <img 
                src={product.imageUrl} 
                alt={product.name} 
                className="w-full h-full object-cover hover:scale-105 transition-transform"
              />
            </div>
            <div className="p-2">
              <h3 className={`font-medium text-sm line-clamp-1 ${hoverColor} transition-colors`}>{product.name}</h3>
              <div className="flex items-center space-x-1 mt-1">
                <span className={`${priceColor} font-bold text-sm`}>
                  R${product.price.toFixed(2).replace('.', ',')}
                </span>
              </div>
            </div>
          </div>
        </Link>
        <div className="px-2 pb-2">
          <Button
            variant="outline"
            size="sm"
            className={`w-full text-xs border-${priceColor.replace('text-', '')} ${priceColor} hover:${buttonColor.split(' ')[0]} hover:text-white`}
            onClick={handleAddToCart}
            disabled={isLoading}
          >
            {isLoading ? "..." : "Adicionar"}
          </Button>
        </div>
      </motion.div>
    );
  }
  
  // Layout compacto
  if (variant === "compact") {
    return (
      <motion.div 
        className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden hover:shadow-lg transition-all"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="flex flex-col md:flex-row">
          <Link href={`/product/${product.id}`}>
            <div className="cursor-pointer md:w-1/3">
              <div className="h-48 md:h-full overflow-hidden">
                <img 
                  src={product.imageUrl} 
                  alt={product.name} 
                  className="w-full h-full object-cover hover:scale-105 transition-transform"
                />
              </div>
            </div>
          </Link>
          <div className="flex flex-col p-4 md:w-2/3 justify-between">
            <div>
              <Link href={`/product/${product.id}`}>
                <h3 className={`font-semibold text-xl mb-2 ${hoverColor} transition-colors`}>{product.name}</h3>
              </Link>
              <p className="text-gray-600 text-sm mb-3 line-clamp-3">{product.description}</p>
              <div className="flex items-center space-x-3 mb-4">
                <span className="text-red-500 line-through text-sm">
                  R${product.originalPrice.toFixed(2).replace('.', ',')}
                </span>
                <span className={`${priceColor} font-bold text-lg`}>
                  R${product.price.toFixed(2).replace('.', ',')}
                </span>
              </div>
            </div>
            <Button
              className={`w-full ${buttonColor}`}
              onClick={handleAddToCart}
              disabled={isLoading}
            >
              {isLoading ? "Adicionando..." : "Adicionar ao Carrinho"}
            </Button>
          </div>
        </div>
      </motion.div>
    );
  }

  return (
    <motion.div 
      className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden hover:shadow-lg transition-all"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <Link href={`/product/${product.id}`}>
        <div className="cursor-pointer">
          <div className="h-56 overflow-hidden">
            <img 
              src={product.imageUrl} 
              alt={product.name} 
              className="w-full h-full object-cover hover:scale-105 transition-transform"
            />
          </div>
          <div className="p-4">
            <h3 className={`font-semibold text-lg mb-1 ${hoverColor} transition-colors`}>{product.name}</h3>
            <p className="text-gray-600 text-sm mb-2 line-clamp-2">{product.description}</p>
            <div className="flex items-center space-x-2 mb-3">
              <span className="text-red-500 line-through text-sm">
                R${product.originalPrice.toFixed(2).replace('.', ',')}
              </span>
              <span className={`${priceColor} font-bold`}>
                R${product.price.toFixed(2).replace('.', ',')}
              </span>
            </div>
          </div>
        </div>
      </Link>
      <div className="px-4 pb-4">
        <Button
          className={`w-full ${buttonColor}`}
          onClick={handleAddToCart}
          disabled={isLoading}
        >
          {isLoading ? "Adicionando..." : "Adicionar ao Carrinho"}
        </Button>
      </div>
    </motion.div>
  );
}