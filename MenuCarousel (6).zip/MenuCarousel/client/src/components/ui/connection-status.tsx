import React, { useState, useEffect } from 'react';
import { Shield, ShieldCheck, ShieldAlert, Loader2 } from 'lucide-react';
import { Badge } from './badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from './tooltip';
import { apiRequest } from '@/lib/queryClient';

// Definindo um timeout curto para evitar que a requisição fique pendente por muito tempo
const API_TIMEOUT_MS = 3000;

type HealthStatus = {
  status: 'healthy' | 'unhealthy' | 'error';
  database: 'connected' | 'disconnected';
  circuitBreaker: 'CLOSED' | 'OPEN' | 'HALF_OPEN';
};

export function ConnectionStatus() {
  const [health, setHealth] = useState<HealthStatus | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkHealth = async () => {
      try {
        setLoading(true);
        
        // Criando uma promessa com timeout
        const timeoutPromise = new Promise<HealthStatus>((_, reject) => {
          setTimeout(() => reject(new Error('Timeout ao verificar status')), API_TIMEOUT_MS);
        });
        
        // Race entre a requisição e o timeout
        const response = await Promise.race([
          apiRequest<HealthStatus>('/api/health'),
          timeoutPromise
        ]);
        
        console.log('Health check response:', response);
        setHealth(response);
      } catch (error) {
        console.error('Erro ao verificar status da conexão:', error);
        setHealth({
          status: 'error',
          database: 'disconnected',
          circuitBreaker: 'OPEN'
        });
      } finally {
        setLoading(false);
      }
    };

    // Verifica na inicialização
    checkHealth();

    // Configura verificação periódica a cada 15 segundos
    const interval = setInterval(checkHealth, 15000);

    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <Badge variant="outline" className="gap-1 py-1 bg-blue-100 border-blue-300 cursor-wait">
        <Loader2 className="h-3.5 w-3.5 animate-spin text-blue-600" />
        <span className="text-xs text-blue-800 font-medium">Verificando...</span>
      </Badge>
    );
  }

  if (!health) {
    return null;
  }

  let icon;
  let tooltipMessage;
  let variant: "default" | "secondary" | "destructive" | "outline" = "outline";

  if (health.status === 'healthy') {
    icon = <ShieldCheck className="h-3.5 w-3.5 text-green-500" />;
    tooltipMessage = 'Banco de dados conectado';
    variant = "outline";
  } else if (health.status === 'unhealthy') {
    icon = <ShieldAlert className="h-3.5 w-3.5 text-amber-500" />;
    tooltipMessage = `Banco de dados desconectado. Circuit breaker: ${health.circuitBreaker}`;
    variant = "secondary";
  } else {
    icon = <Shield className="h-3.5 w-3.5 text-red-500" />;
    tooltipMessage = 'Erro ao verificar conexão com banco de dados';
    variant = "destructive";
  }

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <Badge 
            variant={variant} 
            className={`gap-1 py-1 cursor-pointer font-medium border ${
              health.status === 'healthy' ? 'bg-green-100 border-green-300 hover:bg-green-200' : 
              health.status === 'unhealthy' ? 'bg-yellow-100 border-yellow-300 hover:bg-yellow-200' : 
              'bg-red-100 border-red-300 hover:bg-red-200'
            }`}
          >
            {icon}
            <span className={`text-xs ${
              health.status === 'healthy' ? 'text-green-800' : 
              health.status === 'unhealthy' ? 'text-yellow-800' : 
              'text-red-800'
            }`}>
              {health.status === 'healthy' ? 'BD Online' : 'BD Offline'}
            </span>
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <p>{tooltipMessage}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}