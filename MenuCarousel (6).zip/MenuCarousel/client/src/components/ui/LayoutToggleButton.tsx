import { useLayoutToggle } from "@/hooks/useLayoutToggle";
import { cn } from "@/lib/utils";
import { AnimatePresence, motion } from "framer-motion";
import { 
  IconBallFootball, 
  IconBallBasketball, 
  IconBallVolleyball, 
  IconBallTennis,
  IconSportBillard
} from "@tabler/icons-react";

interface LayoutToggleButtonProps {
  className?: string;
}

export function LayoutToggleButton({ className }: LayoutToggleButtonProps) {
  const { currentCategory, toggleCategory } = useLayoutToggle();
  
  // Definir a cor com base na categoria esportiva atual
  const getButtonColor = () => {
    switch(currentCategory) {
      case 'futebol':
        return "from-green-500 to-emerald-700 hover:from-green-600 hover:to-emerald-800";
      case 'basquete':
        return "from-orange-500 to-red-700 hover:from-orange-600 hover:to-red-800";
      case 'volei':
        return "from-blue-500 to-indigo-700 hover:from-blue-600 hover:to-indigo-800";
      case 'tenis':
        return "from-yellow-500 to-amber-700 hover:from-yellow-600 hover:to-amber-800";
      default:
        return "from-green-500 to-emerald-700 hover:from-green-600 hover:to-emerald-800";
    }
  };
  
  return (
    <motion.button
      onClick={toggleCategory}
      className={cn(
        "fixed z-50 flex items-center justify-center w-16 h-16 rounded-full shadow-lg",
        "bg-gradient-to-r",
        getButtonColor(),
        "focus:outline-none focus:ring-2 focus:ring-offset-2",
        "transition-all transform hover:scale-105 active:scale-95",
        className
      )}
      style={{ 
        left: "50%", 
        transform: "translateX(-50%)",
        bottom: "2rem" 
      }}
      whileHover={{ scale: 1.1 }}
      whileTap={{ scale: 0.95 }}
    >
      <AnimatePresence mode="wait">
        {currentCategory === 'todos' && (
          <motion.div
            key="todos"
            initial={{ opacity: 0, rotate: -180 }}
            animate={{ opacity: 1, rotate: 0 }}
            exit={{ opacity: 0, rotate: 180 }}
            transition={{ duration: 0.3 }}
            className="text-white"
          >
            <IconSportBillard size={28} stroke={3} />
          </motion.div>
        )}
        
        {currentCategory === 'futebol' && (
          <motion.div
            key="futebol"
            initial={{ opacity: 0, rotate: -180 }}
            animate={{ opacity: 1, rotate: 0 }}
            exit={{ opacity: 0, rotate: 180 }}
            transition={{ duration: 0.3 }}
            className="text-white"
          >
            <IconBallFootball size={28} stroke={3} />
          </motion.div>
        )}
        
        {currentCategory === 'basquete' && (
          <motion.div
            key="basquete"
            initial={{ opacity: 0, rotate: -180 }}
            animate={{ opacity: 1, rotate: 0 }}
            exit={{ opacity: 0, rotate: 180 }}
            transition={{ duration: 0.3 }}
            className="text-white"
          >
            <IconBallBasketball size={28} stroke={3} />
          </motion.div>
        )}
        
        {currentCategory === 'volei' && (
          <motion.div
            key="volei"
            initial={{ opacity: 0, rotate: -180 }}
            animate={{ opacity: 1, rotate: 0 }}
            exit={{ opacity: 0, rotate: 180 }}
            transition={{ duration: 0.3 }}
            className="text-white"
          >
            <IconBallVolleyball size={28} stroke={3} />
          </motion.div>
        )}
        
        {currentCategory === 'tenis' && (
          <motion.div
            key="tenis"
            initial={{ opacity: 0, rotate: -180 }}
            animate={{ opacity: 1, rotate: 0 }}
            exit={{ opacity: 0, rotate: 180 }}
            transition={{ duration: 0.3 }}
            className="text-white"
          >
            <IconBallTennis size={28} stroke={3} />
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* Pequeno indicador de posição */}
      <div className="absolute -bottom-6 flex space-x-1">
        <div className={`h-1.5 w-1.5 rounded-full ${currentCategory === 'todos' ? 'bg-white' : 'bg-white/40'}`}></div>
        <div className={`h-1.5 w-1.5 rounded-full ${currentCategory === 'futebol' ? 'bg-white' : 'bg-white/40'}`}></div>
        <div className={`h-1.5 w-1.5 rounded-full ${currentCategory === 'basquete' ? 'bg-white' : 'bg-white/40'}`}></div>
        <div className={`h-1.5 w-1.5 rounded-full ${currentCategory === 'volei' ? 'bg-white' : 'bg-white/40'}`}></div>
        <div className={`h-1.5 w-1.5 rounded-full ${currentCategory === 'tenis' ? 'bg-white' : 'bg-white/40'}`}></div>
      </div>
    </motion.button>
  );
}