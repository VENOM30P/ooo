import { ShoppingCart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/useCart";
import { Product } from "@shared/schema";

interface AddToCartButtonProps {
  product: Product;
  variant?: "default" | "outline" | "small";
  className?: string;
}

export function AddToCartButton({ product, variant = "default", className = "" }: AddToCartButtonProps) {
  const { addToCart } = useCart();
  
  const handleAddToCart = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product);
  };
  
  if (variant === "small") {
    return (
      <Button 
        onClick={handleAddToCart}
        size="sm"
        className={`bg-green-600 hover:bg-green-700 rounded-full p-2 ${className}`}
      >
        <ShoppingCart className="h-4 w-4" />
      </Button>
    );
  }
  
  if (variant === "outline") {
    return (
      <Button 
        onClick={handleAddToCart}
        variant="outline"
        className={`border-green-600 text-green-600 hover:bg-green-50 hover:text-green-700 ${className}`}
      >
        <ShoppingCart className="h-4 w-4 mr-2" />
        Adicionar ao Carrinho
      </Button>
    );
  }
  
  return (
    <Button 
      onClick={handleAddToCart}
      className={`bg-green-600 hover:bg-green-700 ${className}`}
    >
      <ShoppingCart className="h-4 w-4 mr-2" />
      Adicionar ao Carrinho
    </Button>
  );
}