import { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/utils";

interface GradientButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  children: ReactNode;
  className?: string;
  fullWidth?: boolean;
}

export function GradientButton({ 
  children, 
  className, 
  fullWidth = false, 
  ...props 
}: GradientButtonProps) {
  return (
    <button
      className={cn(
        "gradient-btn px-6 py-3 text-white font-semibold rounded-lg shadow-lg",
        fullWidth ? "w-full" : "",
        className
      )}
      {...props}
    >
      {children}
    </button>
  );
}
