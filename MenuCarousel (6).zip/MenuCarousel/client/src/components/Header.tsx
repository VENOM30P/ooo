import { useState } from "react";
import { Link } from "wouter";
import { 
  Search, 
  User, 
  ShoppingCart, 
  Menu 
} from "lucide-react";
import { 
  Sheet, 
  SheetContent, 
  SheetTrigger 
} from "@/components/ui/sheet";
import { useCart } from "@/hooks/useCart";

export default function Header() {
  const { cartCount } = useCart();
  
  return (
    <header className="bg-black text-white sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <Link href="/" className="text-2xl font-bold font-sans">
            <span className="text-[#4CAF50]">ONCE</span> <span className="text-white">11</span>
          </Link>
        </div>
        
        <nav className="hidden md:flex space-x-6">
          <Link href="/" className="hover:text-[#4CAF50] transition-colors">Home</Link>
          <Link href="/produtos" className="hover:text-[#4CAF50] transition-colors">Produtos</Link>
          <Link href="/colecoes" className="hover:text-[#4CAF50] transition-colors">Coleções</Link>
          <Link href="/promocoes" className="hover:text-[#4CAF50] transition-colors">Promoções</Link>
          <Link href="/contato" className="hover:text-[#4CAF50] transition-colors">Contato</Link>
        </nav>
        
        <div className="flex items-center space-x-4">
          <button className="hover:text-[#4CAF50] transition-colors">
            <Search size={20} />
          </button>
          <button className="hover:text-[#4CAF50] transition-colors">
            <User size={20} />
          </button>
          <button className="hover:text-[#4CAF50] transition-colors relative">
            <ShoppingCart size={20} />
            <span className="absolute -top-2 -right-2 bg-[#4CAF50] text-white rounded-full w-5 h-5 flex items-center justify-center text-xs">
              {cartCount}
            </span>
          </button>
        </div>
        
        <Sheet>
          <SheetTrigger className="md:hidden">
            <Menu size={24} />
          </SheetTrigger>
          <SheetContent side="right" className="bg-black text-white">
            <div className="flex flex-col gap-6 mt-8">
              <Link href="/" className="text-lg hover:text-[#4CAF50] transition-colors">Home</Link>
              <Link href="/produtos" className="text-lg hover:text-[#4CAF50] transition-colors">Produtos</Link>
              <Link href="/colecoes" className="text-lg hover:text-[#4CAF50] transition-colors">Coleções</Link>
              <Link href="/promocoes" className="text-lg hover:text-[#4CAF50] transition-colors">Promoções</Link>
              <Link href="/contato" className="text-lg hover:text-[#4CAF50] transition-colors">Contato</Link>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  );
}
