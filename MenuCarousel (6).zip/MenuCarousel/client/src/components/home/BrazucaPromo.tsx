import { Link } from "wouter";

export function BrazucaPromo() {
  return (
    <div className="py-12 bg-gradient-to-br from-green-900 to-green-700 relative overflow-hidden">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 text-white z-10">
            <div className="bg-green-900 bg-opacity-80 p-6 rounded-lg inline-block mb-6">
              <h2 className="text-4xl md:text-6xl font-bold mb-2">50% OFF</h2>
              <p className="text-lg mb-6">
                Coleção exclusiva de uniformes da seleção brasileira. 
                Adquira já o seu e demonstre seu amor pelo futebol brasileiro com estilo e autenticidade.
              </p>
              <div className="flex flex-wrap gap-3">
                <Link href="/colecoes" className="px-5 py-2 bg-gray-200 text-green-900 font-semibold rounded-md hover:bg-white transition-colors">
                  Veja Outras Coleções
                </Link>
                <Link href="/colecao/brazuca" className="px-5 py-2 bg-yellow-400 text-green-900 font-semibold rounded-md hover:bg-yellow-300 transition-colors">
                  <span className="text-blue-600">B</span>
                  <span className="text-green-600">R</span>
                  <span className="text-yellow-600">A</span>
                  <span className="text-blue-600">Z</span>
                  <span className="text-green-600">U</span>
                  <span className="text-blue-600">C</span>
                  <span className="text-yellow-600">A</span>
                </Link>
              </div>
            </div>
          </div>
          <div className="md:w-1/2 flex justify-center mt-6 md:mt-0 z-10">
            <img 
              src="https://images.unsplash.com/photo-1617143207675-e7e6371f5f5d?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&h=400&q=80" 
              alt="Uniformes do Brasil" 
              className="rounded-lg shadow-xl" 
            />
          </div>
        </div>
        
        {/* Background pattern */}
        <div className="absolute bottom-0 left-0 right-0 h-28 bg-red-800 z-0">
          <div className="h-full w-full flex flex-col">
            <div className="flex-1 border-b-2 border-white border-opacity-25"></div>
            <div className="flex-1 border-b-2 border-white border-opacity-25"></div>
            <div className="flex-1 border-b-2 border-white border-opacity-25"></div>
            <div className="flex-1 border-b-2 border-white border-opacity-25"></div>
          </div>
        </div>
      </div>
    </div>
  );
}
