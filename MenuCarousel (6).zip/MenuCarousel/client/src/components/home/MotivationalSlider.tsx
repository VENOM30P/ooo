import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { MotivationalSlide } from "@/lib/types";

export function MotivationalSlider() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const { data: slides = [], isLoading } = useQuery<MotivationalSlide[]>({
    queryKey: ['/api/motivational-slides'],
  });

  useEffect(() => {
    if (slides.length === 0) return;
    
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    
    return () => clearInterval(interval);
  }, [slides]);

  if (isLoading) {
    return (
      <div className="bg-gray-100 py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-5xl mx-auto h-64 md:h-80 bg-gray-200 animate-pulse rounded-lg"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-gray-100 py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-5xl mx-auto overflow-hidden relative">
          <div className="h-64 md:h-80 relative">
            {slides.map((slide, index) => (
              <div 
                key={slide.id} 
                className={`slide absolute inset-0 bg-gray-900 rounded-lg overflow-hidden ${index === currentSlide ? 'opacity-100' : 'opacity-0'}`}
              >
                <img 
                  src={slide.imageUrl} 
                  alt="Motivacional" 
                  className="w-full h-full object-cover opacity-70"
                />
                <div className="absolute inset-0 flex items-center justify-center">
                  <h3 className="text-white text-2xl md:text-4xl font-bold text-center px-6">
                    "{slide.quote}"
                  </h3>
                </div>
              </div>
            ))}
          </div>
          
          {/* Slide navigation dots */}
          <div className="absolute bottom-4 left-0 right-0 flex justify-center space-x-2">
            {slides.map((_, index) => (
              <button 
                key={index}
                className={`w-3 h-3 rounded-full bg-white ${index === currentSlide ? 'opacity-100' : 'opacity-50'}`}
                onClick={() => setCurrentSlide(index)}
              ></button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
