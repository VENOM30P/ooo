import { useProducts } from "@/hooks/useProducts";
import { ProductCard } from "@/components/ui/ProductCard";

export function BestSellers() {
  const { bestSellers: products = [], isLoading } = useProducts();

  // Skeleton loader for product cards
  const ProductSkeleton = () => (
    <div className="bg-white rounded-xl shadow-md border border-gray-200 p-4 animate-pulse">
      <div className="bg-gray-200 w-full h-48 rounded-lg mb-4"></div>
      <div className="bg-gray-200 h-6 w-3/4 rounded mb-2"></div>
      <div className="bg-gray-200 h-4 w-full rounded mb-3"></div>
      <div className="flex justify-between items-center">
        <div className="bg-gray-200 h-4 w-1/4 rounded"></div>
        <div className="bg-gray-200 h-8 w-1/4 rounded"></div>
      </div>
    </div>
  );

  return (
    <div className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">Mais Vendidos</h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {isLoading ? (
            // Show skeleton while loading
            Array(8).fill(0).map((_, index) => (
              <ProductSkeleton key={index} />
            ))
          ) : (
            // Show actual products
            products.map((product) => (
              <ProductCard 
                key={product.id} 
                product={product}
                variant="bestseller"
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
}