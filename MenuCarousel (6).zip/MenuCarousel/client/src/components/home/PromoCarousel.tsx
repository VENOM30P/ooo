// Este componente foi removido
export default function PromoCarousel() {
  return null;
}