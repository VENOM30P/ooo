// Este componente foi removido
export default function SecondarySlider() {
  return null;
}