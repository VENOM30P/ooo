import { GradientButton } from "@/components/ui/GradientButton";
import { Link } from "wouter";

export function HeroBanner() {
  return (
    <div className="relative bg-gray-900 overflow-hidden">
      <div className="container mx-auto px-4 py-8 flex flex-col md:flex-row items-center">
        <div className="text-white md:w-1/2">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            Welcome to <br/>
            <span className="text-green-500">ONCE 11</span>
          </h1>
          <p className="mb-6 text-gray-300 text-lg">
            Estilo e performance para os apaixonados por esporte.
          </p>
          <Link href="/colecoes">
            <GradientButton>
              Explorar Coleção
            </GradientButton>
          </Link>
        </div>
        <div className="md:w-1/2 mt-8 md:mt-0">
          <img 
            src="https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?ixlib=rb-1.2.1&auto=format&fit=crop&w=700&q=80" 
            alt="Tênis esportivos" 
            className="w-full h-auto object-cover rounded-lg shadow-xl" 
          />
        </div>
      </div>
    </div>
  );
}
