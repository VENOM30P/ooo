<footer className="bg-gray-800 text-white py-8">
  <div className="container mx-auto px-4">
    <div className="flex flex-wrap md:flex-row flex-col justify-between">
      <div className="w-full md:w-1/3 mb-8 md:mb-0">
        <h2 className="text-2xl font-bold mb-4">
          Minha Loja
        </h2>
        <p className="text-gray-300">
          © 2023 Minha Loja. Todos os direitos reservados.
        </p>
      </div>
      <div className="w-full md:w-1/3 mb-8 md:mb-0">
        <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">
          Institucional
        </h3>
        <ul className="mt-4 space-y-4">
          <li>
            <a href="#" className="text-base text-gray-300 hover:text-white">
              Sobre Nós
            </a>
          </li>
          <li>
            <a href="/politica-privacidade" className="text-base text-gray-300 hover:text-white">
              Política de Privacidade
            </a>
          </li>
          <li>
            <a href="/termos-condicoes" className="text-base text-gray-300 hover:text-white">
              Termos e Condições
            </a>
          </li>
          <li>
            <a href="#" className="text-base text-gray-300 hover:text-white">
              Parcerias
            </a>
          </li>
        </ul>
      </div>
      <div className="w-full md:w-1/3">
        <h3 className="text-sm font-semibold text-gray-400 tracking-wider uppercase">
          Suporte
        </h3>
        <ul className="mt-4 space-y-4">
          <li>
            <a href="/faq" className="text-base text-gray-300 hover:text-white">
              Perguntas Frequentes
            </a>
          </li>
          <li>
            <a href="/trocas-devolucoes" className="text-base text-gray-300 hover:text-white">
              Trocas e Devoluções
            </a>
          </li>
          <li>
            <a href="#" className="text-base text-gray-300 hover:text-white">
              Garantia
            </a>
          </li>
          <li>
            <a href="/contato" className="text-base text-gray-300 hover:text-white">
              Contato
            </a>
          </li>
        </ul>
      </div>
    </div>
  </div>
</footer>