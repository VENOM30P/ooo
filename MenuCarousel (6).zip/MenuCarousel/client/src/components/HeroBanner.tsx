import { Link } from "wouter";

export default function HeroBanner() {
  return (
    <section className="bg-zinc-900 py-4">
      <div className="container mx-auto px-4">
        <div className="bg-zinc-800 rounded-lg overflow-hidden">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 p-8 md:p-12">
              <h1 className="text-4xl md:text-5xl font-bold text-white font-sans mb-4">
                Welcome to <span className="text-[#4CAF50]">ONCE 11</span>
              </h1>
              <p className="text-gray-300 mb-6">
                Os melhores produtos esportivos para você alcançar o máximo desempenho. 
                Qualidade, estilo e conforto em todos os momentos.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link href="/produtos" className="bg-[#4CAF50] hover:bg-[#125C2F] text-white py-3 px-6 rounded-full font-medium transition duration-300 transform hover:scale-105">
                  Ver Produtos
                </Link>
                <Link href="/colecoes" className="bg-white text-black border-2 border-white hover:bg-transparent hover:text-white py-3 px-6 rounded-full font-medium transition duration-300">
                  Coleções Especiais
                </Link>
              </div>
            </div>
            <div className="md:w-1/2">
              <img 
                src="https://images.unsplash.com/photo-1593390976006-2cda1db7c3a7?q=80&w=800&h=600&auto=format&fit=crop" 
                alt="ONCE 11 Tênis Esportivo" 
                className="w-full h-auto rounded-r-lg object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
