import { Product } from "@shared/schema";
import { useCart } from "@/hooks/useCart";

interface ProductCardProps {
  product: Product;
  variant?: "featured" | "top-selling";
}

export default function ProductCard({ product, variant = "featured" }: ProductCardProps) {
  const { addToCart } = useCart();
  
  return (
    <div className="product-card overflow-hidden">
      <div className="h-56 overflow-hidden">
        <img 
          src={product.imageUrl} 
          alt={product.name} 
          className="w-full h-full object-cover"
        />
      </div>
      <div className="p-4">
        <h3 className="font-semibold text-lg mb-1">{product.name}</h3>
        <p className="text-gray-600 text-sm mb-2">{product.description}</p>
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center space-x-2">
            <span className="text-red-500 line-through text-sm">
              R${product.originalPrice.toFixed(2).replace('.', ',')}
            </span>
            <span className="text-[#0A8043] font-bold">
              R${product.currentPrice.toFixed(2).replace('.', ',')}
            </span>
          </div>
        </div>
        <button 
          className={`${
            variant === "featured" 
              ? "add-to-cart-btn" 
              : "bg-black hover:bg-zinc-800"
          } text-white w-full py-2 rounded-md font-medium transition-colors`}
          onClick={() => addToCart(product)}
        >
          Adicionar ao Carrinho
        </button>
      </div>
    </div>
  );
}
