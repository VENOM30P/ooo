import React, { useState, useEffect } from 'react';
import { Route, Switch } from 'wouter';
import { Toaster } from './components/ui/toaster';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

import { CartProvider } from './hooks/useCart';
import { LayoutProvider } from './hooks/useLayoutToggle';
import Home from './pages/Home';
import Products from './pages/Products';
import ProductDetail from './pages/ProductDetail';
import Cart from './pages/Cart';
import AdminLogin from './pages/AdminLogin';
import AdminDashboard from './pages/AdminDashboard';
import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import Novidades from './pages/Novidades';
import Sobre from './pages/Sobre';
import Contato from './pages/Contato';
import Login from './pages/Login';
import Register from './pages/Register';
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsAndConditions from "./pages/TermsAndConditions";
import ReturnsPolicy from "./pages/ReturnsPolicy";
import FAQ from "./pages/FAQ";

// Componente para tratamento de erros de conexão
interface ErrorBoundaryProps {
  children: React.ReactNode;
}

function ErrorBoundary({ children }: ErrorBoundaryProps) {
  const [hasError, setHasError] = useState(false);
  const [isOffline, setIsOffline] = useState(false);
  const [retryCount, setRetryCount] = useState(0);

  // Monitora o estado de conexão
  useEffect(() => {
    function handleOnline() {
      setIsOffline(false);
      // Tenta reconectar
      window.location.reload();
    }

    function handleOffline() {
      setIsOffline(true);
    }

    // Tratamento de erros globais
    function handleError(event: ErrorEvent) {
      console.error("Erro capturado:", event.error);
      setHasError(true);
    }

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    window.addEventListener('error', handleError);

    // Verifica o estado atual
    setIsOffline(!navigator.onLine);

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      window.removeEventListener('error', handleError);
    };
  }, []);

  // Renderiza o componente de erro se ocorrer
  if (isOffline) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <div className="p-8 max-w-md mx-auto bg-white rounded-lg shadow-lg text-center">
          <h2 className="text-2xl font-bold text-red-600 mb-4">Sem conexão</h2>
          <p className="mb-6">Não foi possível conectar ao servidor. Por favor, verifique sua conexão com a internet.</p>
          <button 
            onClick={() => window.location.reload()} 
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Tentar novamente
          </button>
        </div>
      </div>
    );
  }

  if (hasError) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <div className="p-8 max-w-md mx-auto bg-white rounded-lg shadow-lg text-center">
          <h2 className="text-2xl font-bold text-red-600 mb-4">Ops! Algo deu errado</h2>
          <p className="mb-6">Encontramos um problema ao carregar a aplicação.</p>
          <button 
            onClick={() => {
              setHasError(false);
              window.location.reload();
            }} 
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Tentar novamente
          </button>
        </div>
      </div>
    );
  }

  const retryConnection = () => {
    setRetryCount(prev => prev + 1);
    window.location.reload();
  };

  if (isOffline || hasError) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <div className="p-8 max-w-md mx-auto bg-white rounded-lg shadow-lg text-center">
          <h2 className="text-2xl font-bold text-red-600 mb-4">
            {isOffline ? "Sem conexão" : "Erro ao carregar"}
          </h2>
          <p className="mb-6">Tentando reconectar ao servidor...</p>
          <button 
            onClick={retryConnection}
            className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700"
          >
            Tentar novamente ({retryCount})
          </button>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 3, // Aumenta o número de retentativas
      retryDelay: attempt => Math.min(1000 * 2 ** attempt, 30000), // Exponential backoff
      refetchOnWindowFocus: true, // Atualiza quando o foco volta para a janela
      staleTime: 2 * 60 * 1000, // 2 minutos
      gcTime: 10 * 60 * 1000,
    },
  },
});

function App() {
  return (
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <CartProvider>
          <LayoutProvider>
            <Router>
              <Navbar />
              <main className="min-h-screen pt-24 pb-16">
                <Switch>
                  <Route path="/" component={Home} />
                  <Route path="/products" component={Products} />
                  <Route path="/product/:id" component={ProductDetail} />
                  <Route path="/cart" component={Cart} />
                  <Route path="/login" component={Login} />
                  <Route path="/register" component={Register} />
                  <Route path="/admin" component={AdminLogin} />
                  <Route path="/admin/dashboard" component={AdminDashboard} />
                  <Route path="/novidades" component={Novidades} />
                  <Route path="/sobre" component={Sobre} />
                  <Route path="/contato" component={Contato} />
                  <Route path="/politica-privacidade" component={PrivacyPolicy} />
                  <Route path="/termos-condicoes" component={TermsAndConditions} />
                  <Route path="/trocas-devolucoes" component={ReturnsPolicy} />
                  <Route path="/faq" component={FAQ} />
                </Switch>
              </main>
              <Footer />
            </Router>
            <Toaster />
          </LayoutProvider>
        </CartProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  );
}

function Router({ children }: { children: React.ReactNode }) {
  return (
    <div className="app-container">
      {children}
    </div>
  );
}

export default App;