export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  originalPrice: number;
  imageUrl: string;
  category: string;
  inStock: boolean;
  isPromoted: boolean;
  isBestSeller: boolean;
}

export interface MotivationalSlide {
  id: number;
  imageUrl: string;
  quote: string;
}

export interface StorySlide {
  id: number;
  imageUrl: string;
  title: string;
  description: string;
}
