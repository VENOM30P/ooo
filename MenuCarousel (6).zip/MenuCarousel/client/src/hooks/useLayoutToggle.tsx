import { createContext, useContext, useState, ReactNode, useEffect } from 'react';

// Categorias esportivas conforme solicitado (adicionando uma categoria "todos")
export type SportCategoryType = 'futebol' | 'basquete' | 'volei' | 'tenis' | 'todos';

interface LayoutContextType {
  currentCategory: SportCategoryType;
  toggleCategory: () => void;
  setCategory: (category: SportCategoryType) => void;
  getCategoryColor: (category?: SportCategoryType) => string;
  getCategoryButtonColor: (category?: SportCategoryType) => string;
  // Aliases para manter compatibilidade com código existente
  currentLayout: SportCategoryType;
  toggleLayout: () => void;
  setLayout: (layout: SportCategoryType) => void;
}

// Mapeamento de cores para cada categoria de esporte (texto)
export const categoryColors = {
  futebol: 'text-green-600',
  basquete: 'text-orange-600',
  volei: 'text-blue-600',
  tenis: 'text-yellow-600',
  todos: 'text-purple-600'
};

// Mapeamento de cores para botões de cada categoria
export const categoryButtonColors = {
  futebol: 'bg-green-600 hover:bg-green-700',
  basquete: 'bg-orange-600 hover:bg-orange-700',
  volei: 'bg-blue-600 hover:bg-blue-700',
  tenis: 'bg-yellow-600 hover:bg-yellow-700',
  todos: 'bg-purple-600 hover:bg-purple-700'
};

const LayoutContext = createContext<LayoutContextType | undefined>(undefined);

export function LayoutProvider({ children }: { children: ReactNode }) {
  // Check localStorage for saved preference, default to 'todos' if none
  const [currentCategory, setCurrentCategory] = useState<SportCategoryType>(() => {
    const savedCategory = localStorage.getItem('sport-category');
    // Verificamos se o valor guardado é válido para o nosso tipo
    const validCategories = ['futebol', 'basquete', 'volei', 'tenis', 'todos'];
    if (savedCategory && validCategories.includes(savedCategory)) {
      return savedCategory as SportCategoryType;
    }
    return 'todos'; // Começamos mostrando todos os produtos
  });

  // Save preference to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem('sport-category', currentCategory);
  }, [currentCategory]);

  // Função para alternar entre as 5 categorias esportivas em sequência
  const toggleCategory = () => {
    setCurrentCategory(prevCategory => {
      if (prevCategory === 'todos') return 'futebol';
      if (prevCategory === 'futebol') return 'basquete';
      if (prevCategory === 'basquete') return 'volei';
      if (prevCategory === 'volei') return 'tenis';
      return 'todos'; // de tenis volta para todos
    });
  };

  // Função para definir uma categoria específica
  const setCategory = (category: SportCategoryType) => {
    setCurrentCategory(category);
  };

  // Função para obter a cor de texto baseada na categoria
  const getCategoryColor = (category?: SportCategoryType) => {
    const cat = category || currentCategory;
    return categoryColors[cat];
  };

  // Função para obter a cor de botão baseada na categoria
  const getCategoryButtonColor = (category?: SportCategoryType) => {
    const cat = category || currentCategory;
    return categoryButtonColors[cat];
  };

  return (
    <LayoutContext.Provider value={{ 
      currentCategory, 
      toggleCategory, 
      setCategory,
      getCategoryColor,
      getCategoryButtonColor,
      // Aliases para manter compatibilidade com código existente
      currentLayout: currentCategory,
      toggleLayout: toggleCategory,
      setLayout: setCategory
    }}>
      {children}
    </LayoutContext.Provider>
  );
}

export function useLayoutToggle() {
  const context = useContext(LayoutContext);
  if (context === undefined) {
    throw new Error('useLayoutToggle must be used within a LayoutProvider');
  }
  return context;
}