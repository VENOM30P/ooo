import { useQuery } from "@tanstack/react-query";
import { Product } from "@/lib/types";
import { apiRequest } from "@/lib/queryClient";
import { useLayoutToggle } from "./useLayoutToggle";

export function useProducts() {
  const { currentCategory } = useLayoutToggle();
  
  // Fetch products in promotion
  const { 
    data: promotedProducts = [],
    isLoading: isLoadingPromoted,
    isError: isErrorPromoted,
  } = useQuery({
    queryKey: ['/api/products/promotions'],
    queryFn: () => apiRequest<Product[]>('/api/products/promotions'),
  });

  // Fetch best selling products
  const { 
    data: bestSellerProducts = [],
    isLoading: isLoadingBestSellers,
    isError: isErrorBestSellers,
  } = useQuery({
    queryKey: ['/api/products/bestsellers'],
    queryFn: () => apiRequest<Product[]>('/api/products/bestsellers'),
  });

  // All products query (can be used on the Products page)
  const {
    data: allProducts = [],
    isLoading: isLoadingAll,
    isError: isErrorAll,
  } = useQuery({
    queryKey: ['/api/products'],
    queryFn: () => apiRequest<Product[]>('/api/products'),
  });

  // Get the products to display based on the current category
  const getDisplayProducts = () => {
    if (currentCategory === 'todos' || currentCategory === 'futebol') {
      return promotedProducts;
    } else {
      return bestSellerProducts;
    }
  };

  return {
    promotedProducts,
    bestSellerProducts,
    allProducts,
    displayProducts: getDisplayProducts(),
    isLoadingPromoted,
    isLoadingBestSellers,
    isLoadingAll,
    isLoading: isLoadingPromoted || isLoadingBestSellers || isLoadingAll,
    isErrorPromoted,
    isErrorBestSellers,
    isErrorAll,
    hasError: isErrorPromoted || isErrorBestSellers || isErrorAll,
  };
}