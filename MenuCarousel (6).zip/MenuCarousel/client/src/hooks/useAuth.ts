import { useState, useEffect } from 'react';

export const useAuth = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [user, setUser] = useState<{id: string, username: string} | null>(null);

  useEffect(() => {
    const token = localStorage.getItem('token');
    const userId = localStorage.getItem('userId');
    const username = localStorage.getItem('username');
    const isAdminStr = localStorage.getItem('isAdmin');

    if (token && userId && username) {
      setIsAuthenticated(true);
      setUser({ id: userId, username });
      setIsAdmin(isAdminStr === 'true');
    }
  }, []);

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('userId');
    localStorage.removeItem('username');
    localStorage.removeItem('isAdmin');
    setIsAuthenticated(false);
    setUser(null);
    setIsAdmin(false);
  };

  return {
    isAuthenticated,
    isAdmin,
    user,
    logout
  };
};
