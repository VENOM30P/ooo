
import { useEffect, useState } from "react";
import { useRoute, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Product } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { useCart } from "@/hooks/useCart";
import { useProducts } from "@/hooks/useProducts";
import { ProductCard } from "@/components/ui/ProductCard";
import { LayoutToggleButton } from "@/components/ui/LayoutToggleButton";
import { useLayoutToggle } from "@/hooks/useLayoutToggle";
import { motion } from "framer-motion";
import { 
  ArrowLeft, 
  ShoppingCart, 
  Heart, 
  Leaf, 
  Thermometer, 
  Clock, 
  Award,
  Share2,
  ChevronRight,
  ChevronLeft,
} from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function ProductDetail() {
  const [_, params] = useRoute("/product/:id");
  const productId = params?.id;
  const [isLoading, setIsLoading] = useState(false);
  const [quantity, setQuantity] = useState(1);
  const [isFavorite, setIsFavorite] = useState(false);
  const { addToCart } = useCart();
  const { currentCategory } = useLayoutToggle();
  const { bestSellerProducts, isLoadingBestSellers } = useProducts();

  // Buscar produto pelo ID
  const { data: product, isLoading: isProductLoading } = useQuery({
    queryKey: ["/api/products", productId],
    queryFn: () => apiRequest<Product>(`/api/products/${productId}`),
    enabled: !!productId,
  });

  // Informações de preparo e benefícios (simuladas, pois não temos no back-end)
  const preparation = {
    temperature: "85°C",
    time: "3-5 minutos",
    amount: "1 colher para 200ml",
    tips: "Para liberar todos os aromas, aguarde 1 minuto após ferver a água antes de despejar sobre as folhas."
  };

  const benefits = [
    "Rica em antioxidantes",
    "Auxilia na digestão",
    "Propriedades calmantes",
    "Auxilia no sistema imunológico",
    "Melhora a qualidade do sono"
  ];

  // Aumentar quantidade
  const increaseQuantity = () => {
    setQuantity(prev => prev + 1);
  };

  // Diminuir quantidade
  const decreaseQuantity = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
    }
  };

  // Adicionar ao carrinho com a quantidade selecionada
  const handleAddToCart = () => {
    if (!product) return;
    
    try {
      setIsLoading(true);
      // Adicionamos a quantidade de vezes que o usuário selecionou
      for (let i = 0; i < quantity; i++) {
        addToCart(product as Product);
      }
    } catch (error) {
      console.error("Failed to add to cart:", error);
    } finally {
      setIsLoading(false);
    }
  };

  // Alternar favorito
  const toggleFavorite = () => {
    setIsFavorite(!isFavorite);
  };

  if (isProductLoading) {
    return (
      <div className="container mx-auto py-8 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="animate-pulse">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="bg-gray-200 rounded-lg h-96"></div>
              <div className="space-y-4">
                <div className="h-8 bg-gray-200 rounded w-3/4"></div>
                <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                <div className="h-32 bg-gray-200 rounded"></div>
                <div className="h-10 bg-gray-200 rounded w-1/3"></div>
                <div className="h-12 bg-gray-200 rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="container mx-auto py-8 px-4 text-center">
        <h1 className="text-2xl font-bold mb-4">Produto não encontrado</h1>
        <Link href="/" className="text-green-600 hover:underline">
          Voltar para a página inicial
        </Link>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8 px-4 relative">
      <div className="max-w-6xl mx-auto">
        <nav className="flex items-center text-sm text-gray-600 mb-6">
          <Link href="/" className="hover:text-green-600">Início</Link>
          <ChevronRight size={14} className="mx-2" />
          <Link href="/products" className="hover:text-green-600">Produtos</Link>
          <ChevronRight size={14} className="mx-2" />
          <span className="text-gray-800 font-medium truncate">{product.name}</span>
        </nav>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {/* Imagem do produto */}
          <motion.div 
            className="bg-white p-6 rounded-xl shadow-md overflow-hidden"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4 }}
          >
            <div className="relative">
              {product.isPromoted && (
                <div className="absolute top-4 left-4 bg-red-500 text-white text-xs font-bold px-3 py-1 rounded-full">
                  Promoção
                </div>
              )}
              {product.isBestSeller && (
                <div className="absolute top-4 right-4 bg-amber-500 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center">
                  <Award size={14} className="mr-1" />
                  Mais Vendido
                </div>
              )}
              <img
                src={product.imageUrl}
                alt={product.name}
                className="w-full h-auto object-contain rounded-lg transition-transform hover:scale-105"
                style={{ maxHeight: "450px" }}
              />
            </div>
          </motion.div>

          {/* Detalhes do produto */}
          <motion.div
            className="flex flex-col"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 }}
          >
            <h1 className="text-3xl md:text-4xl font-bold mb-2">{product.name}</h1>
            <div className="flex items-center mb-4">
              <span className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm">
                {product.category}
              </span>
              {product.inStock ? (
                <span className="ml-3 text-sm text-green-600">Em estoque</span>
              ) : (
                <span className="ml-3 text-sm text-red-600">Fora de estoque</span>
              )}
            </div>

            <div className="flex items-center mb-6">
              {product.originalPrice > product.price && (
                <span className="line-through text-red-500 mr-3 text-lg">
                  R${product.originalPrice.toFixed(2).replace(".", ",")}
                </span>
              )}
              <span className="text-green-600 font-bold text-3xl">
                R${product.price.toFixed(2).replace(".", ",")}
              </span>
              {product.originalPrice > product.price && (
                <span className="ml-3 bg-red-100 text-red-800 px-2 py-1 rounded-md text-xs font-semibold">
                  {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
                </span>
              )}
            </div>

            <p className="text-gray-700 mb-6 leading-relaxed">
              {product.description}
            </p>

            <div className="flex items-center space-x-4 mb-6">
              <div className="flex items-center border rounded-lg">
                <button 
                  onClick={decreaseQuantity}
                  className="px-4 py-2 border-r text-xl font-medium text-gray-700 hover:bg-gray-100"
                >
                  -
                </button>
                <span className="px-4 py-2 text-gray-800">{quantity}</span>
                <button 
                  onClick={increaseQuantity}
                  className="px-4 py-2 border-l text-xl font-medium text-gray-700 hover:bg-gray-100"
                >
                  +
                </button>
              </div>
              <Button
                className="flex-1 py-6 text-lg bg-green-600 hover:bg-green-700"
                onClick={handleAddToCart}
                disabled={isLoading}
              >
                <ShoppingCart className="mr-2" size={20} />
                {isLoading ? "Adicionando..." : "Adicionar ao Carrinho"}
              </Button>
              <Button
                variant="outline"
                className={`p-3 ${isFavorite ? "text-red-500 border-red-200" : "text-gray-400"}`}
                onClick={toggleFavorite}
              >
                <Heart className={isFavorite ? "fill-red-500" : ""} size={20} />
              </Button>
            </div>

            <div className="grid grid-cols-3 gap-3 mb-6">
              <div className="flex flex-col items-center justify-center p-3 border rounded-lg bg-green-50">
                <Leaf className="text-green-600 mb-1" size={20} />
                <span className="text-xs text-center text-gray-800">100% Natural</span>
              </div>
              <div className="flex flex-col items-center justify-center p-3 border rounded-lg bg-blue-50">
                <Thermometer className="text-blue-600 mb-1" size={20} />
                <span className="text-xs text-center text-gray-800">{preparation.temperature}</span>
              </div>
              <div className="flex flex-col items-center justify-center p-3 border rounded-lg bg-amber-50">
                <Clock className="text-amber-600 mb-1" size={20} />
                <span className="text-xs text-center text-gray-800">{preparation.time}</span>
              </div>
            </div>

            <div className="flex items-center justify-between mt-auto">
              <Button variant="ghost" size="sm" className="text-gray-500">
                <Share2 size={18} className="mr-1" />
                Compartilhar
              </Button>
            </div>
          </motion.div>
        </div>

        {/* Tabs com informações adicionais */}
        <motion.div
          className="mb-16"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.2 }}
        >
          <Tabs defaultValue="preparation" className="w-full">
            <TabsList className="grid grid-cols-3 mb-8">
              <TabsTrigger value="preparation">Modo de Preparo</TabsTrigger>
              <TabsTrigger value="benefits">Benefícios</TabsTrigger>
              <TabsTrigger value="reviews">Avaliações</TabsTrigger>
            </TabsList>
            <TabsContent value="preparation" className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-xl font-semibold mb-4 flex items-center">
                <Thermometer className="mr-2 text-green-600" />
                Modo de Preparo
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <div className="mb-4">
                    <h4 className="font-medium text-gray-700 mb-1">Temperatura:</h4>
                    <p>{preparation.temperature}</p>
                  </div>
                  <div className="mb-4">
                    <h4 className="font-medium text-gray-700 mb-1">Tempo de Infusão:</h4>
                    <p>{preparation.time}</p>
                  </div>
                  <div className="mb-4">
                    <h4 className="font-medium text-gray-700 mb-1">Proporção:</h4>
                    <p>{preparation.amount}</p>
                  </div>
                </div>
                <div>
                  <h4 className="font-medium text-gray-700 mb-1">Dicas para o preparo perfeito:</h4>
                  <p className="text-gray-600">{preparation.tips}</p>
                </div>
              </div>
            </TabsContent>
            <TabsContent value="benefits" className="bg-white p-6 rounded-xl shadow-sm">
              <h3 className="text-xl font-semibold mb-4 flex items-center">
                <Leaf className="mr-2 text-green-600" />
                Benefícios para Saúde
              </h3>
              <ul className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {benefits.map((benefit, index) => (
                  <li key={index} className="flex items-center">
                    <div className="h-2 w-2 rounded-full bg-green-500 mr-2"></div>
                    {benefit}
                  </li>
                ))}
              </ul>
            </TabsContent>
            <TabsContent value="reviews" className="bg-white p-6 rounded-xl shadow-sm">
              <div className="text-center py-8">
                <h3 className="text-xl font-semibold mb-2">Avaliações</h3>
                <p className="text-gray-600 mb-4">Seja o primeiro a avaliar este produto!</p>
                <Button className="bg-green-600 hover:bg-green-700">Escrever Avaliação</Button>
              </div>
            </TabsContent>
          </Tabs>
        </motion.div>

        {/* Produtos relacionados */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, delay: 0.3 }}
        >
          <h2 className="text-2xl font-bold mb-6">Você também pode gostar</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {isLoadingBestSellers ? (
              Array.from({ length: 4 }).map((_, i) => (
                <div key={i} className="bg-gray-100 rounded-lg p-4 h-64 animate-pulse" />
              ))
            ) : (
              bestSellerProducts
                .filter(p => p.id !== parseInt(productId || "0"))
                .slice(0, 4)
                .map(relatedProduct => (
                  <ProductCard key={relatedProduct.id} product={relatedProduct} variant="featured" />
                ))
            )}
          </div>
        </motion.div>
      </div>
      
      {/* Botão de toggle de layout */}
      <LayoutToggleButton />
    </div>
  );
}
