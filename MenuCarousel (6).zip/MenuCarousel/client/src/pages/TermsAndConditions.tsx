
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function TermsAndConditions() {
  return (
    <div className="container mx-auto px-4 py-12">
      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="text-3xl font-bold">Termos e Condições</CardTitle>
          <CardDescription>Última atualização: 11 de Março de 2025</CardDescription>
        </CardHeader>
        <CardContent className="prose prose-zinc max-w-none">
          <p>
            Bem-vindo à Loja Sneakers. Ao acessar ou usar nosso site, você concorda com estes Termos e Condições. 
            Por favor, leia-os cuidadosamente antes de fazer qualquer compra.
          </p>
          
          <h2 className="text-xl font-semibold mt-6">Uso do site</h2>
          <p>
            Você concorda em usar nosso site apenas para fins legais e de maneira que não infrinja os direitos de, 
            restrinja ou iniba o uso e aproveitamento do site por qualquer terceiro. Tal restrição ou inibição inclui, 
            sem limitação, conduta que seja ilegal ou que possa assediar ou causar desconforto ou inconveniência a qualquer pessoa.
          </p>
          
          <h2 className="text-xl font-semibold mt-6">Contas de usuário</h2>
          <p>
            Ao criar uma conta em nosso site, você é responsável por:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-2">
            <li>Fornecer informações precisas e atualizadas</li>
            <li>Manter a confidencialidade de sua senha</li>
            <li>Todas as atividades que ocorrem em sua conta</li>
          </ul>
          <p>
            Reservamo-nos o direito de encerrar contas inativas ou que violem estes Termos.
          </p>
          
          <h2 className="text-xl font-semibold mt-6">Produtos e preços</h2>
          <p>
            Fazemos todos os esforços para exibir com precisão as cores e imagens de nossos produtos. No entanto, 
            não podemos garantir que a exibição de qualquer cor em seu monitor seja precisa.
          </p>
          <p>
            Os preços dos produtos estão sujeitos a alterações sem aviso prévio. Reservamo-nos o direito de 
            descontinuar qualquer produto a qualquer momento.
          </p>
          
          <h2 className="text-xl font-semibold mt-6">Pedidos e pagamentos</h2>
          <p>
            Reservamo-nos o direito de recusar ou cancelar pedidos a nosso critério, incluindo casos em que 
            identificamos um erro no preço ou na descrição do produto, ou se suspeitarmos de fraude.
          </p>
          <p>
            Aceitamos várias formas de pagamento, como listado em nosso site. Ao fornecer informações de pagamento, 
            você confirma que está autorizado a usar o método de pagamento especificado.
          </p>
          
          <h2 className="text-xl font-semibold mt-6">Entregas</h2>
          <p>
            Os prazos de entrega são estimados e podem variar de acordo com a disponibilidade do produto, 
            sua localização e outros fatores. Não somos responsáveis por atrasos causados por terceiros ou por 
            circunstâncias fora de nosso controle.
          </p>
          
          <h2 className="text-xl font-semibold mt-6">Propriedade intelectual</h2>
          <p>
            Todo o conteúdo do site, incluindo textos, gráficos, logotipos, ícones, imagens, clipes de áudio, 
            downloads digitais e software, é propriedade da Loja Sneakers ou de seus fornecedores de conteúdo e 
            está protegido por leis nacionais e internacionais de direitos autorais.
          </p>
          
          <h2 className="text-xl font-semibold mt-6">Limitação de responsabilidade</h2>
          <p>
            Em nenhuma circunstância a Loja Sneakers será responsável por quaisquer danos diretos, indiretos, 
            especiais, punitivos, incidentais, exemplares ou consequentes, resultantes do uso ou incapacidade de 
            uso do site ou de qualquer produto adquirido.
          </p>
          
          <h2 className="text-xl font-semibold mt-6">Lei aplicável</h2>
          <p>
            Estes Termos e Condições são regidos e interpretados de acordo com as leis brasileiras. Qualquer disputa 
            relacionada a estes termos será submetida à jurisdição exclusiva dos tribunais da cidade de São Paulo.
          </p>
          
          <h2 className="text-xl font-semibold mt-6">Alterações nos termos</h2>
          <p>
            Podemos revisar estes Termos e Condições a qualquer momento, atualizando esta página. Ao continuar a usar 
            nosso site após tais alterações, você concorda com os novos termos.
          </p>
          
          <h2 className="text-xl font-semibold mt-6">Contato</h2>
          <p>
            Se você tiver dúvidas sobre estes Termos, entre em contato conosco em <a href="mailto:termos@lojasneakers.com" className="text-primary hover:underline">termos@lojasneakers.com</a>.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
