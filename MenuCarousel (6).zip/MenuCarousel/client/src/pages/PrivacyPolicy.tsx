
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function PrivacyPolicy() {
  return (
    <div className="container mx-auto px-4 py-12">
      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="text-3xl font-bold">Política de Privacidade</CardTitle>
          <CardDescription>Última atualização: 11 de Março de 2025</CardDescription>
        </CardHeader>
        <CardContent className="prose prose-zinc max-w-none">
          <p>
            A sua privacidade é importante para nós. Esta Política de Privacidade explica como coletamos, usamos, divulgamos, 
            transferimos e armazenamos suas informações. Dedique alguns minutos para se familiarizar com nossas práticas de privacidade.
          </p>
          
          <h2 className="text-xl font-semibold mt-6">Informações que coletamos</h2>
          <p>
            Coletamos diferentes tipos de informações para fornecer e melhorar nossos produtos e serviços para você:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-2">
            <li><strong>Informações pessoais:</strong> Quando você cria uma conta, faz uma compra ou entra em contato conosco, podemos coletar uma variedade de informações, incluindo seu nome, endereço, número de telefone e endereço de e-mail.</li>
            <li><strong>Informações de pagamento:</strong> Quando você faz uma compra, coletamos as informações necessárias para processar seu pagamento, incluindo seu método de pagamento e informações relacionadas.</li>
            <li><strong>Informações de uso:</strong> Coletamos informações sobre como você usa nosso site, como quais páginas você visita, os produtos que você visualiza e as ações que você realiza.</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-6">Como usamos suas informações</h2>
          <p>
            Usamos suas informações pessoais para:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-2">
            <li>Processar e entregar seus pedidos</li>
            <li>Gerenciar sua conta e fornecer suporte ao cliente</li>
            <li>Personalizar sua experiência de compra</li>
            <li>Informá-lo sobre novos produtos, ofertas especiais e eventos</li>
            <li>Melhorar nossos produtos e serviços</li>
            <li>Proteger contra fraudes e atividades não autorizadas</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-6">Compartilhamento de informações</h2>
          <p>
            Não vendemos ou alugamos suas informações pessoais a terceiros. Podemos compartilhar suas informações com:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-2">
            <li>Provedores de serviços que nos ajudam a operar nosso negócio</li>
            <li>Parceiros de logística para entregar seus pedidos</li>
            <li>Autoridades governamentais quando exigido por lei</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-6">Cookies e tecnologias semelhantes</h2>
          <p>
            Usamos cookies e tecnologias semelhantes para melhorar sua experiência, lembrar suas preferências e entender como você usa nosso site. Você pode gerenciar suas preferências de cookies através das configurações do seu navegador.
          </p>
          
          <h2 className="text-xl font-semibold mt-6">Seus direitos</h2>
          <p>
            Você tem o direito de:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-2">
            <li>Acessar e corrigir suas informações pessoais</li>
            <li>Solicitar a exclusão de suas informações</li>
            <li>Retirar seu consentimento a qualquer momento</li>
            <li>Opor-se ao processamento de suas informações</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-6">Segurança</h2>
          <p>
            Tomamos medidas para proteger suas informações contra acesso não autorizado, alteração, divulgação ou destruição. Essas medidas incluem salvaguardas físicas, eletrônicas e processuais.
          </p>
          
          <h2 className="text-xl font-semibold mt-6">Alterações nesta política</h2>
          <p>
            Podemos atualizar esta Política de Privacidade periodicamente. Publicaremos qualquer alteração em nosso site e, se as alterações forem significativas, forneceremos um aviso mais proeminente.
          </p>
          
          <h2 className="text-xl font-semibold mt-6">Contato</h2>
          <p>
            Se você tiver dúvidas sobre nossa Política de Privacidade, entre em contato conosco em <a href="mailto:privacidade@lojasneakers.com" className="text-primary hover:underline">privacidade@lojasneakers.com</a>.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
