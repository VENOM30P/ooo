
import { HeroBanner } from "@/components/home/HeroBanner";
import { BrazucaPromo } from "@/components/home/BrazucaPromo";
import { ProductGrid } from "@/components/products/ProductGrid";
import { LayoutToggleButton } from "@/components/ui/LayoutToggleButton";
import { useProducts } from "@/hooks/useProducts";
import { useLayoutToggle } from "@/hooks/useLayoutToggle";

export default function Home() {
  const { displayProducts, isLoading } = useProducts();
  const { currentCategory } = useLayoutToggle();
  
  // Teste de debugger - Para confirmar que a página está carregando
  console.log("Home page loaded! Category:", currentCategory);
  
  // Define o título baseado na categoria atual
  const title = currentCategory === 'todos' || currentCategory === 'futebol'
    ? "Produtos em Promoção" 
    : "Produtos Mais Vendidos";
  
  return (
    <div className="relative">
      <HeroBanner />
      <ProductGrid 
        title={title} 
        products={displayProducts} 
        isLoading={isLoading} 
      />
      <BrazucaPromo />
      
      {/* Adiciona o botão de alternância de layout */}
      <LayoutToggleButton />
    </div>
  );
}
