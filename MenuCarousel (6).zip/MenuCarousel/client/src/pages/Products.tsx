import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation, Link } from "wouter";
import { Product } from "@/lib/types";
import { ProductGrid } from "@/components/products/ProductGrid";
import { apiRequest } from "@/lib/queryClient";
import { LayoutToggleButton } from "@/components/ui/LayoutToggleButton";
import { useLayoutToggle, SportCategoryType } from "@/hooks/useLayoutToggle";
import { 
  IconBallFootball, 
  IconBallBasketball, 
  IconBallVolleyball, 
  IconBallTennis,
  IconSportBillard
} from "@tabler/icons-react";

export default function Products() {
  const { currentCategory, setCategory, getCategoryButtonColor } = useLayoutToggle();
  const [location] = useLocation();
  const params = new URLSearchParams(location.split('?')[1] || '');
  const urlCategory = params.get('category') as SportCategoryType | null;
  
  // Sincroniza a categoria da URL com o estado global quando a página carrega
  useEffect(() => {
    if (urlCategory && ['todos', 'futebol', 'basquete', 'volei', 'tenis'].includes(urlCategory)) {
      setCategory(urlCategory as SportCategoryType);
    }
  }, [urlCategory, setCategory]);

  const { data: products = [], isLoading } = useQuery<Product[]>({
    queryKey: ['/api/products'],
    queryFn: () => apiRequest('/api/products')
  });

  // Filtra produtos com base na categoria esportiva atual
  const filteredProducts = currentCategory === 'todos'
    ? products
    : products.filter(product => {
        // Aqui podemos adaptar para filtrar baseado na categoria esportiva
        // Por enquanto, vamos usar uma lógica simples de correspondência
        switch (currentCategory) {
          case 'futebol':
            return product.category.toLowerCase().includes('futebol') || 
                  product.category.toLowerCase().includes('soccer');
          case 'basquete':
            return product.category.toLowerCase().includes('basquete') || 
                  product.category.toLowerCase().includes('basketball');
          case 'volei':
            return product.category.toLowerCase().includes('volei') || 
                  product.category.toLowerCase().includes('volleyball');
          case 'tenis':
            return product.category.toLowerCase().includes('tenis') || 
                  product.category.toLowerCase().includes('tennis');
          default:
            return true;
        }
      });

  // Títulos das categorias esportivas
  const sportCategoryTitles = {
    todos: "Todos os Produtos",
    futebol: "Produtos de Futebol",
    basquete: "Produtos de Basquete",
    volei: "Produtos de Vôlei",
    tenis: "Produtos de Tênis"
  };

  return (
    <div className="container mx-auto px-4 py-12">
      <div className="flex flex-col space-y-4 mb-8">
        <div className="flex justify-between items-center">
          <h1 className="text-3xl font-bold">
            {sportCategoryTitles[currentCategory]}
          </h1>
        </div>
        
        {/* Navegação por ícones esportivos */}
        <div className="flex flex-wrap gap-3 items-center">
          <Link href="/products?category=todos">
            <div className={`flex items-center justify-center p-3 rounded-full transition-all ${currentCategory === 'todos' ? getCategoryButtonColor('todos') + ' text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>
              <IconSportBillard size={22} className="mr-2" />
              <span className="font-medium text-sm">Todos</span>
            </div>
          </Link>
          <Link href="/products?category=futebol">
            <div className={`flex items-center justify-center p-3 rounded-full transition-all ${currentCategory === 'futebol' ? getCategoryButtonColor('futebol') + ' text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>
              <IconBallFootball size={22} className="mr-2" />
              <span className="font-medium text-sm">Futebol</span>
            </div>
          </Link>
          <Link href="/products?category=basquete">
            <div className={`flex items-center justify-center p-3 rounded-full transition-all ${currentCategory === 'basquete' ? getCategoryButtonColor('basquete') + ' text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>
              <IconBallBasketball size={22} className="mr-2" />
              <span className="font-medium text-sm">Basquete</span>
            </div>
          </Link>
          <Link href="/products?category=volei">
            <div className={`flex items-center justify-center p-3 rounded-full transition-all ${currentCategory === 'volei' ? getCategoryButtonColor('volei') + ' text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>
              <IconBallVolleyball size={22} className="mr-2" />
              <span className="font-medium text-sm">Vôlei</span>
            </div>
          </Link>
          <Link href="/products?category=tenis">
            <div className={`flex items-center justify-center p-3 rounded-full transition-all ${currentCategory === 'tenis' ? getCategoryButtonColor('tenis') + ' text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>
              <IconBallTennis size={22} className="mr-2" />
              <span className="font-medium text-sm">Tênis</span>
            </div>
          </Link>
        </div>
      </div>

      {/* Usando o componente ProductGrid com os 3 layouts */}
      <ProductGrid 
        products={filteredProducts} 
        isLoading={isLoading} 
      />
      
      {/* Adicionando o botão de alternância de layout */}
      <LayoutToggleButton />
    </div>
  );
}