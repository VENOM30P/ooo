import { useForm } from "react-hook-form";
import type { FC } from "react";

interface ContactFormData {
  nome: string;
  email: string;
  assunto: string;
  mensagem: string;
}

const Contato: FC = () => {
  const { register, handleSubmit, formState: { errors } } = useForm<ContactFormData>();

  const onSubmit = (data: ContactFormData) => {
    console.log(data);
    alert("Mensagem enviada com sucesso! Entraremos em contato em breve.");
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Entre em Contato</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div>
          <div className="bg-white shadow-md rounded-lg p-6 mb-6">
            <h2 className="text-xl font-semibold mb-4">Informações de Contato</h2>
            <div className="space-y-3">
              <p className="flex items-center">
                <span className="font-semibold mr-2">Endereço:</span> 
                Av. Paulista, 1000 - São Paulo, SP
              </p>
              <p className="flex items-center">
                <span className="font-semibold mr-2">Email:</span> 
                contato@minhaloja.com
              </p>
              <p className="flex items-center">
                <span className="font-semibold mr-2">Telefone:</span> 
                (11) 3456-7890
              </p>
              <p className="flex items-center">
                <span className="font-semibold mr-2">Horário de Atendimento:</span> 
                Segunda a Sexta, 9h às 18h
              </p>
            </div>
          </div>

          <div className="bg-white shadow-md rounded-lg p-6">
            <h2 className="text-xl font-semibold mb-4">Nos Siga nas Redes Sociais</h2>
            <div className="flex space-x-4">
              <a href="#" className="text-blue-600 hover:text-blue-800">
                Facebook
              </a>
              <a href="#" className="text-pink-600 hover:text-pink-800">
                Instagram
              </a>
              <a href="#" className="text-blue-400 hover:text-blue-600">
                Twitter
              </a>
            </div>
          </div>
        </div>

        <div className="bg-white shadow-md rounded-lg p-6">
          <h2 className="text-xl font-semibold mb-4">Envie uma Mensagem</h2>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <label htmlFor="nome" className="block text-sm font-medium text-gray-700 mb-1">
                Nome Completo
              </label>
              <input
                id="nome"
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                {...register("nome", { required: "Nome é obrigatório" })}
              />
              {errors.nome && (
                <span className="text-red-500 text-sm">{errors.nome.message}</span>
              )}
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Email
              </label>
              <input
                id="email"
                type="email"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                {...register("email", { 
                  required: "Email é obrigatório",
                  pattern: {
                    value: /^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i,
                    message: "Email inválido"
                  }
                })}
              />
              {errors.email && (
                <span className="text-red-500 text-sm">{errors.email.message}</span>
              )}
            </div>

            <div>
              <label htmlFor="assunto" className="block text-sm font-medium text-gray-700 mb-1">
                Assunto
              </label>
              <input
                id="assunto"
                type="text"
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                {...register("assunto", { required: "Assunto é obrigatório" })}
              />
              {errors.assunto && (
                <span className="text-red-500 text-sm">{errors.assunto.message}</span>
              )}
            </div>

            <div>
              <label htmlFor="mensagem" className="block text-sm font-medium text-gray-700 mb-1">
                Mensagem
              </label>
              <textarea
                id="mensagem"
                rows={5}
                className="w-full px-3 py-2 border border-gray-300 rounded-md"
                {...register("mensagem", { required: "Mensagem é obrigatória" })}
              ></textarea>
              {errors.mensagem && (
                <span className="text-red-500 text-sm">{errors.mensagem.message}</span>
              )}
            </div>

            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors"
            >
              Enviar Mensagem
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Contato;