
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

export default function ReturnsPolicy() {
  return (
    <div className="container mx-auto px-4 py-12">
      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="text-3xl font-bold">Trocas e Devoluções</CardTitle>
          <CardDescription>Última atualização: 11 de Março de 2025</CardDescription>
        </CardHeader>
        <CardContent className="prose prose-zinc max-w-none">
          <p>
            Na Loja Sneakers, queremos garantir sua total satisfação com suas compras. Entendemos que ocasionalmente 
            você pode precisar trocar ou devolver um produto. Esta política foi desenvolvida para tornar esse processo 
            o mais simples possível.
          </p>
          
          <h2 className="text-xl font-semibold mt-6">Prazo para trocas e devoluções</h2>
          <p>
            Você tem até 30 dias após o recebimento do produto para solicitar uma troca ou devolução.
          </p>
          
          <h2 className="text-xl font-semibold mt-6">Condições para trocas e devoluções</h2>
          <p>
            Para que um produto seja elegível para troca ou devolução, ele deve:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-2">
            <li>Estar em sua embalagem original</li>
            <li>Estar em condição de novo, sem sinais de uso</li>
            <li>Ter todas as etiquetas e acessórios originais</li>
            <li>Ser acompanhado da nota fiscal de compra</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-6">Motivos para trocas</h2>
          <p>
            Aceitamos trocas pelos seguintes motivos:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-2">
            <li><strong>Tamanho ou cor incorretos:</strong> Se o produto recebido não corresponder ao tamanho ou cor solicitado.</li>
            <li><strong>Defeito de fabricação:</strong> Se o produto apresentar qualquer defeito de fabricação.</li>
            <li><strong>Produto danificado durante o transporte:</strong> Se o produto chegar danificado.</li>
            <li><strong>Produto diferente do anunciado:</strong> Se o produto recebido for diferente do que foi anunciado no site.</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-6">Como solicitar uma troca ou devolução</h2>
          <p>
            Para solicitar uma troca ou devolução, siga estes passos:
          </p>
          <ol className="list-decimal pl-6 mt-2 space-y-2">
            <li>Acesse sua conta no nosso site e vá para "Meus Pedidos"</li>
            <li>Selecione o pedido e o produto que deseja trocar ou devolver</li>
            <li>Selecione o motivo da troca ou devolução</li>
            <li>Siga as instruções para enviar o produto de volta para nós</li>
          </ol>
          <p>
            Você também pode entrar em contato com nosso atendimento ao cliente pelo e-mail <a href="mailto:trocas@lojasneakers.com" className="text-primary hover:underline">trocas@lojasneakers.com</a> ou 
            pelo telefone (11) 5555-5555.
          </p>
          
          <h2 className="text-xl font-semibold mt-6">Custos de envio para trocas e devoluções</h2>
          <p>
            Os custos de envio serão tratados da seguinte forma:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-2">
            <li><strong>Erro nosso:</strong> Se a troca ou devolução for necessária devido a um erro nosso (produto errado, danificado ou com defeito), nós cobriremos os custos de envio para retorno e reenvio.</li>
            <li><strong>Arrependimento de compra ou seleção incorreta:</strong> Se a troca ou devolução for solicitada por arrependimento ou porque você selecionou o tamanho ou cor errado, você será responsável pelos custos de envio para retorno.</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-6">Processamento do reembolso</h2>
          <p>
            Após recebermos e inspecionarmos o produto devolvido, processaremos seu reembolso. O valor será creditado usando o mesmo método de pagamento utilizado na compra original.
          </p>
          <p>
            O tempo para o reembolso aparecer em sua conta pode variar de acordo com o método de pagamento:
          </p>
          <ul className="list-disc pl-6 mt-2 space-y-2">
            <li><strong>Cartão de crédito:</strong> 5 a 10 dias úteis</li>
            <li><strong>Boleto bancário:</strong> 7 a 15 dias úteis</li>
            <li><strong>PIX:</strong> 1 a 3 dias úteis</li>
          </ul>
          
          <h2 className="text-xl font-semibold mt-6">Produtos em promoção</h2>
          <p>
            Produtos adquiridos em promoções especiais ou liquidações podem ter políticas de troca e devolução diferentes. 
            Verifique as condições específicas anunciadas para cada promoção.
          </p>
          
          <h2 className="text-xl font-semibold mt-6">Dúvidas</h2>
          <p>
            Se você tiver dúvidas sobre nossa política de trocas e devoluções, entre em contato com nosso atendimento ao cliente. 
            Estamos à disposição para ajudar.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
