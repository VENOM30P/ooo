
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function FAQ() {
  return (
    <div className="container mx-auto px-4 py-12">
      <Card className="max-w-4xl mx-auto">
        <CardHeader>
          <CardTitle className="text-3xl font-bold">Perguntas Frequentes</CardTitle>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="item-1">
              <AccordionTrigger className="text-lg font-medium">
                Como faço para rastrear meu pedido?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                Você pode rastrear seu pedido fazendo login em sua conta e acessando a seção "Meus Pedidos". 
                Lá você encontrará o número de rastreamento e um link direto para acompanhar a entrega. 
                Também enviamos atualizações sobre o status do seu pedido por e-mail.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-2">
              <AccordionTrigger className="text-lg font-medium">
                Quais são as formas de pagamento aceitas?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                Aceitamos as seguintes formas de pagamento:
                <ul className="list-disc pl-6 mt-2 space-y-1">
                  <li>Cartões de crédito (Visa, Mastercard, American Express, Elo)</li>
                  <li>Cartões de débito</li>
                  <li>Boleto bancário</li>
                  <li>PIX</li>
                  <li>PayPal</li>
                </ul>
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-3">
              <AccordionTrigger className="text-lg font-medium">
                Qual é o prazo de entrega?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                O prazo de entrega varia conforme a região de entrega e o método de envio escolhido:
                <ul className="list-disc pl-6 mt-2 space-y-1">
                  <li><strong>Entrega Expressa:</strong> 1 a 3 dias úteis (capitais e regiões metropolitanas)</li>
                  <li><strong>Entrega Standard:</strong> 3 a 7 dias úteis</li>
                  <li><strong>Entrega Econômica:</strong> 7 a 15 dias úteis</li>
                </ul>
                O prazo começa a contar após a confirmação do pagamento e aprovação do pedido.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-4">
              <AccordionTrigger className="text-lg font-medium">
                Como sei qual é o tamanho ideal para mim?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                Cada produto em nosso site possui uma tabela de medidas específica na descrição. Recomendamos medir seus pés em centímetros e consultar essa tabela antes de fazer sua compra.
                
                Para obter a medida mais precisa, meça seu pé no final do dia, quando ele está naturalmente mais dilatado, e use essa medida como referência.
                
                Se estiver entre dois tamanhos, recomendamos escolher o maior.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-5">
              <AccordionTrigger className="text-lg font-medium">
                Os produtos são originais?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                Sim, todos os produtos vendidos em nossa loja são 100% originais, adquiridos diretamente dos fabricantes ou distribuidores autorizados. Fornecemos garantia de autenticidade para todos os nossos produtos.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-6">
              <AccordionTrigger className="text-lg font-medium">
                Posso cancelar meu pedido?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                Você pode solicitar o cancelamento do seu pedido se ele ainda não tiver sido enviado. Para isso, acesse sua conta, vá até "Meus Pedidos" e selecione a opção "Cancelar Pedido". Caso o pedido já esteja em processo de envio, entre em contato com nosso atendimento ao cliente o mais rápido possível.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-7">
              <AccordionTrigger className="text-lg font-medium">
                Como faço para trocar um produto?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                Para solicitar uma troca, siga os passos detalhados em nossa <a href="/trocas-devolucoes" className="text-primary hover:underline">política de trocas e devoluções</a>. Em resumo, você precisa entrar em contato com nosso atendimento ao cliente dentro de 30 dias após o recebimento do produto, e ele deve estar em condições adequadas para troca.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-8">
              <AccordionTrigger className="text-lg font-medium">
                Vocês entregam para todo o Brasil?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                Sim, realizamos entregas para todos os estados e municípios do Brasil. Os prazos e custos de envio variam conforme a localidade e podem ser calculados na página de checkout antes de finalizar a compra.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-9">
              <AccordionTrigger className="text-lg font-medium">
                Vocês oferecem frete grátis?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                Sim! Oferecemos frete grátis para compras acima de R$ 300,00 para todo o Brasil em entregas standard. Promoções especiais de frete grátis para valores menores podem estar disponíveis em datas especiais, fique de olho em nosso site.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-10">
              <AccordionTrigger className="text-lg font-medium">
                Posso comprar como pessoa jurídica?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                Sim, aceitamos compras de pessoas jurídicas. Para emissão de nota fiscal com CNPJ, basta informar os dados da empresa durante o processo de compra. Para compras em maior volume ou condições especiais, entre em contato com nosso setor de vendas corporativas em <a href="mailto:empresas@lojasneakers.com" className="text-primary hover:underline">empresas@lojasneakers.com</a>.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-11">
              <AccordionTrigger className="text-lg font-medium">
                As imagens dos produtos são reais?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                Sim, nos esforçamos para apresentar imagens reais e precisas de todos os produtos. No entanto, podem existir pequenas variações de cor devido às configurações de monitor e condições de iluminação usadas nas fotos.
              </AccordionContent>
            </AccordionItem>
            
            <AccordionItem value="item-12">
              <AccordionTrigger className="text-lg font-medium">
                Como faço para obter mais informações sobre um produto?
              </AccordionTrigger>
              <AccordionContent className="text-gray-600">
                Se você precisa de informações adicionais que não estão na descrição do produto, entre em contato com nosso atendimento ao cliente por e-mail, chat ou telefone. Faremos o possível para responder suas dúvidas o mais rápido possível.
              </AccordionContent>
            </AccordionItem>
          </Accordion>
          
          <div className="mt-8 p-4 bg-gray-50 rounded-lg">
            <h3 className="text-lg font-semibold mb-2">Não encontrou o que procura?</h3>
            <p className="text-gray-600 mb-4">
              Entre em contato com nosso atendimento ao cliente:
            </p>
            <ul className="space-y-2">
              <li className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                <span>Email: <a href="mailto:atendimento@lojasneakers.com" className="text-primary hover:underline">atendimento@lojasneakers.com</a></span>
              </li>
              <li className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
                <span>Telefone: (11) 5555-5555</span>
              </li>
              <li className="flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-gray-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                </svg>
                <span>Chat: Disponível de segunda a sexta, das 8h às 20h</span>
              </li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
