
import React from "react";

const Colecoes: React.FC = () => {
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-6">Nossas Coleções</h1>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white shadow-md rounded-lg overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1600185365926-3a2ce3cdb9eb?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" 
            alt="Coleção Verão" 
            className="w-full h-64 object-cover"
          />
          <div className="p-4">
            <h2 className="text-xl font-semibold mb-2">Coleção Verão</h2>
            <p className="text-gray-600">Nossa nova coleção de verão com peças leves e coloridas.</p>
          </div>
        </div>
        
        <div className="bg-white shadow-md rounded-lg overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1551232864-3f0890e580d9?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" 
            alt="Coleção Esportiva" 
            className="w-full h-64 object-cover"
          />
          <div className="p-4">
            <h2 className="text-xl font-semibold mb-2">Coleção Esportiva</h2>
            <p className="text-gray-600">Roupas e acessórios para todas as suas atividades físicas.</p>
          </div>
        </div>
        
        <div className="bg-white shadow-md rounded-lg overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1560243563-062bfc001d68?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" 
            alt="Coleção Casual" 
            className="w-full h-64 object-cover"
          />
          <div className="p-4">
            <h2 className="text-xl font-semibold mb-2">Coleção Casual</h2>
            <p className="text-gray-600">Peças confortáveis para o seu dia a dia.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Colecoes;
