
import { useState, useEffect } from "react";
import { Link } from "wouter";
import { useCart } from "@/hooks/useCart";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Check } from "lucide-react";

export default function OrderSummary() {
  const { items, totalPrice } = useCart();
  const [orderNumber, setOrderNumber] = useState("");

  useEffect(() => {
    // Generate a random order number
    setOrderNumber(`${Math.floor(Math.random() * 1000000)}`.padStart(6, '0'));
  }, []);

  return (
    <div className="container mx-auto py-10 px-4">
      <div className="max-w-2xl mx-auto bg-white p-6 rounded-lg shadow-md">
        <div className="flex items-center justify-center mb-6">
          <div className="h-16 w-16 bg-green-100 rounded-full flex items-center justify-center">
            <Check className="h-8 w-8 text-green-600" />
          </div>
        </div>

        <h1 className="text-2xl font-bold text-center mb-6">Pedido Confirmado!</h1>
        
        <div className="text-center mb-4">
          <p className="text-gray-600">Número do pedido: <span className="font-semibold">{orderNumber}</span></p>
        </div>

        <div className="border-t border-b py-4 my-6">
          <h2 className="font-semibold mb-4">Resumo do Pedido</h2>
          
          {items.map((item) => (
            <div key={item.id} className="flex justify-between py-2">
              <div>
                <p>{item.product?.name} <span className="text-gray-500">x{item.quantity}</span></p>
              </div>
              <div className="font-medium">
                R$ {((item.product?.price || 0) * item.quantity).toFixed(2)}
              </div>
            </div>
          ))}
          
          <div className="flex justify-between pt-4 font-bold">
            <p>Total</p>
            <p>R$ {totalPrice.toFixed(2)}</p>
          </div>
        </div>
        
        <div className="text-center mt-8">
          <p className="text-gray-600 mb-6">
            Um e-mail de confirmação foi enviado com os detalhes do pedido.
          </p>
          
          <Link href="/">
            <Button variant="outline" className="mr-4">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Voltar para a Loja
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
