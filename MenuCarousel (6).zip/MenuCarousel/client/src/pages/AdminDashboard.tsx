import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { useToast } from "@/hooks/use-toast";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Product } from "@shared/schema";
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from "@/components/ui/tabs";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Switch } from "@/components/ui/switch";
import { LogOut, Plus, Trash2, Edit, Package } from "lucide-react";

// Esquema de validação para o produto
const productSchema = z.object({
  name: z.string().min(3, { message: "Nome deve ter no mínimo 3 caracteres" }),
  description: z.string().min(10, { message: "Descrição deve ter no mínimo 10 caracteres" }),
  price: z.coerce.number().positive({ message: "Preço deve ser um valor positivo" }),
  originalPrice: z.coerce.number().positive({ message: "Preço original deve ser um valor positivo" }),
  imageUrl: z.string().url({ message: "URL de imagem inválida" }),
  category: z.string().min(1, { message: "Categoria é obrigatória" }),
  inStock: z.boolean().default(true),
  isPromoted: z.boolean().default(false),
  isBestSeller: z.boolean().default(false),
});

type ProductFormValues = z.infer<typeof productSchema>;

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("products");
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);

  // Verificar se o administrador está logado e se é o usuário específico
  useEffect(() => {
    const adminLoggedIn = localStorage.getItem('adminLoggedIn');
    const adminUser = localStorage.getItem('adminUser');
    
    if (adminLoggedIn !== 'true' || adminUser !== 'meuAdminEspecial') {
      toast({
        title: "Acesso negado",
        description: "Este painel é exclusivo e não está disponível para outros usuários.",
        variant: "destructive",
      });
      setLocation("/admin");
    }
  }, [setLocation, toast]);

  // Logout do administrador
  const handleLogout = () => {
    localStorage.removeItem('adminLoggedIn');
    toast({
      title: "Logout realizado",
      description: "Você foi desconectado do painel de administração.",
      variant: "default",
    });
    setLocation("/admin/login");
  };

  // Buscar produtos
  const { data: products, isLoading: isLoadingProducts } = useQuery({
    queryKey: ['/api/products'],
    queryFn: () => apiRequest<Product[]>('/api/products'),
  });

  // Formulário para adicionar/editar produto
  const form = useForm<ProductFormValues>({
    resolver: zodResolver(productSchema),
    defaultValues: {
      name: "",
      description: "",
      price: 0,
      originalPrice: 0,
      imageUrl: "",
      category: "",
      inStock: true,
      isPromoted: false,
      isBestSeller: false,
    },
  });

  // Atualizar formulário quando estiver editando um produto
  useEffect(() => {
    if (editingProduct) {
      form.reset({
        name: editingProduct.name,
        description: editingProduct.description,
        price: editingProduct.price,
        originalPrice: editingProduct.originalPrice,
        imageUrl: editingProduct.imageUrl,
        category: editingProduct.category,
        inStock: editingProduct.inStock,
        isPromoted: editingProduct.isPromoted || false,
        isBestSeller: editingProduct.isBestSeller || false,
      });
    }
  }, [editingProduct, form]);

  // Mutação para adicionar produto
  const addProductMutation = useMutation({
    mutationFn: (data: ProductFormValues) => 
      apiRequest<Product>('/api/products', {
        method: 'POST',
        body: JSON.stringify(data),
      }),
    onSuccess: () => {
      toast({
        title: "Produto adicionado",
        description: "O produto foi adicionado com sucesso.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Erro ao adicionar produto",
        description: `Ocorreu um erro: ${error}`,
        variant: "destructive",
      });
    }
  });

  // Mutação para atualizar produto
  const updateProductMutation = useMutation({
    mutationFn: (data: {id: number, product: ProductFormValues}) => 
      apiRequest<Product>(`/api/products/${data.id}`, {
        method: 'PATCH',
        body: JSON.stringify(data.product),
      }),
    onSuccess: () => {
      toast({
        title: "Produto atualizado",
        description: "O produto foi atualizado com sucesso.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
      setEditingProduct(null);
      form.reset();
    },
    onError: (error) => {
      toast({
        title: "Erro ao atualizar produto",
        description: `Ocorreu um erro: ${error}`,
        variant: "destructive",
      });
    }
  });

  // Mutação para remover produto
  const deleteProductMutation = useMutation({
    mutationFn: (id: number) => 
      apiRequest<{success: boolean}>(`/api/products/${id}`, {
        method: 'DELETE',
      }),
    onSuccess: () => {
      toast({
        title: "Produto removido",
        description: "O produto foi removido com sucesso.",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/products'] });
    },
    onError: (error) => {
      toast({
        title: "Erro ao remover produto",
        description: `Ocorreu um erro: ${error}`,
        variant: "destructive",
      });
    }
  });

  // Função para lidar com o envio do formulário
  const onSubmit = (data: ProductFormValues) => {
    if (editingProduct) {
      updateProductMutation.mutate({ id: editingProduct.id, product: data });
    } else {
      addProductMutation.mutate(data);
    }
  };

  // Cancelar edição
  const handleCancelEdit = () => {
    setEditingProduct(null);
    form.reset();
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Painel de Administração</h1>
          <p className="text-sm text-green-600 mt-1">Acesso exclusivo - Painel personalizado</p>
        </div>
        <Button 
          variant="outline" 
          className="flex items-center space-x-2"
          onClick={handleLogout}
        >
          <LogOut size={16} />
          <span>Sair</span>
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2 lg:w-[400px]">
          <TabsTrigger value="products">Produtos</TabsTrigger>
          <TabsTrigger value="add-product">
            {editingProduct ? "Editar Produto" : "Adicionar Produto"}
          </TabsTrigger>
          <TabsTrigger value="users">Usuários</TabsTrigger> {/* Added Users Tab */}
        </TabsList>

        {/* Tab para listar produtos */}
        <TabsContent value="products">
          <Card>
            <CardHeader>
              <CardTitle>Gerenciar Produtos</CardTitle>
              <CardDescription>
                Visualize, edite ou remova os produtos da loja.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingProducts ? (
                <div className="text-center py-8">Carregando produtos...</div>
              ) : !products || products.length === 0 ? (
                <div className="text-center py-8">
                  <Package size={48} className="mx-auto text-gray-300 mb-3" />
                  <p className="text-gray-500">Nenhum produto encontrado</p>
                  <Button 
                    onClick={() => setActiveTab("add-product")} 
                    className="mt-4 bg-green-600 hover:bg-green-700"
                  >
                    <Plus size={16} className="mr-2" />
                    Adicionar produto
                  </Button>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-gray-100">
                        <th className="px-4 py-3 text-left">Imagem</th>
                        <th className="px-4 py-3 text-left">Nome</th>
                        <th className="px-4 py-3 text-left">Categoria</th>
                        <th className="px-4 py-3 text-right">Preço</th>
                        <th className="px-4 py-3 text-center">Status</th>
                        <th className="px-4 py-3 text-center">Ações</th>
                      </tr>
                    </thead>
                    <tbody>
                      {products.map((product) => (
                        <tr key={product.id} className="border-b">
                          <td className="px-4 py-3">
                            <img 
                              src={product.imageUrl} 
                              alt={product.name} 
                              className="w-12 h-12 object-cover rounded"
                            />
                          </td>
                          <td className="px-4 py-3">
                            <div className="font-semibold">{product.name}</div>
                          </td>
                          <td className="px-4 py-3 text-gray-600">
                            {product.category}
                          </td>
                          <td className="px-4 py-3 text-right">
                            <div className="font-medium">R$ {product.price.toFixed(2)}</div>
                            {product.originalPrice > product.price && (
                              <div className="text-sm text-gray-500 line-through">
                                R$ {product.originalPrice.toFixed(2)}
                              </div>
                            )}
                          </td>
                          <td className="px-4 py-3 text-center">
                            <div className="flex flex-col items-center text-xs space-y-1">
                              {product.inStock ? (
                                <span className="bg-green-100 text-green-800 px-2 py-1 rounded-full">Em estoque</span>
                              ) : (
                                <span className="bg-red-100 text-red-800 px-2 py-1 rounded-full">Sem estoque</span>
                              )}
                              {product.isPromoted && (
                                <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full">Promoção</span>
                              )}
                              {product.isBestSeller && (
                                <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded-full">Mais vendido</span>
                              )}
                            </div>
                          </td>
                          <td className="px-4 py-3">
                            <div className="flex justify-center space-x-2">
                              <Button 
                                variant="outline" 
                                size="sm"
                                className="p-1 h-8 w-8"
                                onClick={() => {
                                  setEditingProduct(product);
                                  setActiveTab("add-product");
                                }}
                              >
                                <Edit size={14} />
                              </Button>
                              <Button 
                                variant="outline" 
                                size="sm"
                                className="p-1 h-8 w-8 text-red-500 hover:text-red-600 hover:border-red-300"
                                onClick={() => {
                                  if (window.confirm(`Tem certeza que deseja excluir o produto "${product.name}"?`)) {
                                    deleteProductMutation.mutate(product.id);
                                  }
                                }}
                              >
                                <Trash2 size={14} />
                              </Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab para adicionar/editar produto */}
        <TabsContent value="add-product">
          <Card>
            <CardHeader>
              <CardTitle>{editingProduct ? "Editar Produto" : "Adicionar Novo Produto"}</CardTitle>
              <CardDescription>
                {editingProduct 
                  ? "Atualize as informações do produto existente."
                  : "Preencha o formulário para adicionar um novo produto à loja."}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome do Produto</FormLabel>
                          <FormControl>
                            <Input placeholder="Ex: Tênis Nike Air Max" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Categoria</FormLabel>
                          <FormControl>
                            <Input placeholder="Ex: Calçados, Camisetas, etc." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Descrição</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Descreva o produto em detalhes..." 
                            rows={4}
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="price"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Preço de Venda (R$)</FormLabel>
                          <FormControl>
                            <Input type="number" step="0.01" min="0" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="originalPrice"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Preço Original (R$)</FormLabel>
                          <FormControl>
                            <Input type="number" step="0.01" min="0" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="imageUrl"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>URL da Imagem</FormLabel>
                        <FormControl>
                          <Input 
                            placeholder="https://exemplo.com/imagem.jpg" 
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="inStock"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between p-3 border rounded-md">
                          <div>
                            <FormLabel>Em Estoque</FormLabel>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="isPromoted"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between p-3 border rounded-md">
                          <div>
                            <FormLabel>Em Promoção</FormLabel>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="isBestSeller"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-center justify-between p-3 border rounded-md">
                          <div>
                            <FormLabel>Mais Vendido</FormLabel>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="flex justify-end space-x-2 pt-4">
                    {editingProduct && (
                      <Button 
                        type="button" 
                        variant="outline"
                        onClick={handleCancelEdit}
                      >
                        Cancelar
                      </Button>
                    )}
                    <Button 
                      type="submit" 
                      className="bg-green-600 hover:bg-green-700"
                      disabled={addProductMutation.isPending || updateProductMutation.isPending}
                    >
                      {editingProduct ? (
                        updateProductMutation.isPending ? "Salvando..." : "Salvar alterações"
                      ) : (
                        addProductMutation.isPending ? "Adicionando..." : "Adicionar produto"
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="users"> {/* Added Users Tab Content */}
          <Card>
            <CardHeader>
              <CardTitle>Gerenciar Usuários</CardTitle>
            </CardHeader>
            <CardContent>
              {/* Add User Management UI Here */}
              <p>Conteúdo para gerenciamento de usuários será adicionado aqui.</p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}