import { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Product } from "@shared/schema";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Checkbox } from "@/components/ui/checkbox";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { ProductCard } from "@/components/ui/ProductCard";
import { useToast } from "@/hooks/use-toast";
import { 
  Search as SearchIcon, 
  X, 
  SlidersHorizontal, 
  ChevronLeft 
} from "lucide-react";

// Tirar parâmetros da URL
const getSearchParamsFromUrl = () => {
  if (typeof window === "undefined") return {};
  
  const searchParams = new URLSearchParams(window.location.search);
  return {
    query: searchParams.get("q") || "",
    categories: searchParams.getAll("category"),
    minPrice: Number(searchParams.get("minPrice") || 0),
    maxPrice: Number(searchParams.get("maxPrice") || 1000),
    inStock: searchParams.get("inStock") === "true",
  };
};

export default function Search() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  
  // Estados para os filtros
  const [searchParams, setSearchParams] = useState(getSearchParamsFromUrl());
  const [showMobileFilters, setShowMobileFilters] = useState(false);
  const [priceRange, setPriceRange] = useState<[number, number]>([
    searchParams.minPrice || 0,
    searchParams.maxPrice || 1000,
  ]);
  
  const [availableCategories, setAvailableCategories] = useState<string[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>(
    searchParams.categories || []
  );
  
  const [searchQuery, setSearchQuery] = useState(searchParams.query || "");
  const [inStockOnly, setInStockOnly] = useState(searchParams.inStock || false);
  
  // Carregar todos os produtos
  const { data: allProducts, isLoading: isLoadingProducts } = useQuery({
    queryKey: ['/api/products'],
    queryFn: () => apiRequest<Product[]>('/api/products'),
  });
  
  // Extrair as categorias disponíveis dos produtos
  useEffect(() => {
    if (allProducts) {
      // Usar um objeto para rastrear categorias únicas em vez de Set
      const categorySet: Record<string, boolean> = {};
      allProducts.forEach(product => {
        categorySet[product.category] = true;
      });
      const categories = Object.keys(categorySet);
      setAvailableCategories(categories);
    }
  }, [allProducts]);
  
  // Função para filtrar produtos
  const filteredProducts = allProducts ? allProducts.filter(product => {
    // Filtro de pesquisa por texto
    const matchesSearch = searchQuery 
      ? product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        product.description.toLowerCase().includes(searchQuery.toLowerCase())
      : true;
    
    // Filtro de categoria
    const matchesCategory = selectedCategories.length > 0 
      ? selectedCategories.includes(product.category)
      : true;
    
    // Filtro de preço
    const matchesPrice = product.price >= priceRange[0] && product.price <= priceRange[1];
    
    // Filtro de estoque
    const matchesStock = inStockOnly ? product.inStock : true;
    
    return matchesSearch && matchesCategory && matchesPrice && matchesStock;
  }) : [];
  
  // Atualizar URL com parâmetros de pesquisa
  const updateUrlWithFilters = () => {
    const params = new URLSearchParams();
    
    if (searchQuery) params.set("q", searchQuery);
    
    selectedCategories.forEach(category => {
      params.append("category", category);
    });
    
    params.set("minPrice", priceRange[0].toString());
    params.set("maxPrice", priceRange[1].toString());
    
    if (inStockOnly) params.set("inStock", "true");
    
    const newUrl = `/search?${params.toString()}`;
    setLocation(newUrl, { replace: true });
  };
  
  // Atualizar URL quando os filtros mudarem
  useEffect(() => {
    updateUrlWithFilters();
  }, [searchQuery, selectedCategories, priceRange, inStockOnly]);
  
  // Manipuladores de eventos
  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    updateUrlWithFilters();
  };
  
  const handleCategoryChange = (category: string, checked: boolean) => {
    if (checked) {
      setSelectedCategories([...selectedCategories, category]);
    } else {
      setSelectedCategories(selectedCategories.filter(c => c !== category));
    }
  };
  
  const handleClearFilters = () => {
    setSearchQuery("");
    setSelectedCategories([]);
    setPriceRange([0, 1000]);
    setInStockOnly(false);
    
    toast({
      title: "Filtros limpos",
      description: "Todos os filtros foram removidos.",
    });
  };
  
  return (
    <div className="container mx-auto px-4 py-6">
      <div className="mb-6">
        <Link href="/" className="inline-flex items-center text-gray-600 hover:text-gray-900">
          <ChevronLeft size={18} />
          <span className="ml-1">Voltar à loja</span>
        </Link>
      </div>
      
      <h1 className="text-3xl font-bold mb-2">Procurar Produtos</h1>
      
      {/* Barra de pesquisa */}
      <form onSubmit={handleSearch} className="flex mb-6">
        <div className="relative flex-grow">
          <Input
            type="text"
            placeholder="O que você está procurando?"
            className="pr-10 py-2 rounded-l-md"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
          {searchQuery && (
            <button
              type="button"
              className="absolute right-12 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
              onClick={() => setSearchQuery("")}
            >
              <X size={16} />
            </button>
          )}
          <div className="absolute inset-y-0 right-0 flex items-center pr-3">
            <SearchIcon size={18} className="text-gray-400" />
          </div>
        </div>
        <Button type="submit" className="bg-green-600 hover:bg-green-700 rounded-l-none">
          Buscar
        </Button>
      </form>
      
      <div className="flex flex-col md:flex-row gap-6">
        {/* Filtros para desktop */}
        <div className="hidden md:block w-full md:w-64 flex-shrink-0">
          <div className="bg-white p-4 rounded-lg shadow mb-4">
            <div className="flex justify-between items-center mb-4">
              <h2 className="font-semibold text-lg">Filtros</h2>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={handleClearFilters}
                className="text-xs text-gray-500 hover:text-gray-700"
              >
                Limpar filtros
              </Button>
            </div>
            
            <Accordion type="multiple" defaultValue={["categories", "price", "stock"]} className="space-y-2">
              {/* Categorias */}
              <AccordionItem value="categories" className="border-b">
                <AccordionTrigger className="text-base font-medium">
                  Categorias
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-2 pt-1">
                    {availableCategories.map((category) => (
                      <div key={category} className="flex items-center space-x-2">
                        <Checkbox 
                          id={`category-${category}`} 
                          checked={selectedCategories.includes(category)}
                          onCheckedChange={(checked) => 
                            handleCategoryChange(category, checked as boolean)
                          }
                        />
                        <label 
                          htmlFor={`category-${category}`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {category}
                        </label>
                      </div>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
              
              {/* Faixa de preço */}
              <AccordionItem value="price" className="border-b">
                <AccordionTrigger className="text-base font-medium">
                  Preço
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-6">
                    <Slider
                      min={0}
                      max={1000}
                      step={10}
                      value={priceRange}
                      onValueChange={(value) => setPriceRange(value as [number, number])}
                      className="my-6"
                    />
                    <div className="flex items-center justify-between">
                      <div className="bg-gray-100 rounded-md px-2 py-1">
                        <span className="text-xs text-gray-500">R$</span>
                        <span className="text-sm font-medium ml-1">{priceRange[0]}</span>
                      </div>
                      <div className="bg-gray-100 rounded-md px-2 py-1">
                        <span className="text-xs text-gray-500">R$</span>
                        <span className="text-sm font-medium ml-1">{priceRange[1]}</span>
                      </div>
                    </div>
                  </div>
                </AccordionContent>
              </AccordionItem>
              
              {/* Disponibilidade */}
              <AccordionItem value="stock" className="border-b">
                <AccordionTrigger className="text-base font-medium">
                  Disponibilidade
                </AccordionTrigger>
                <AccordionContent>
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id="inStock" 
                      checked={inStockOnly}
                      onCheckedChange={(checked) => setInStockOnly(!!checked)}
                    />
                    <label 
                      htmlFor="inStock"
                      className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                    >
                      Apenas produtos em estoque
                    </label>
                  </div>
                </AccordionContent>
              </AccordionItem>
            </Accordion>
          </div>
        </div>
        
        {/* Botão para filtros em dispositivos móveis */}
        <div className="md:hidden mb-4">
          <Button 
            onClick={() => setShowMobileFilters(true)} 
            variant="outline"
            className="w-full flex items-center justify-center"
          >
            <SlidersHorizontal size={16} className="mr-2" />
            Filtros e Categorias
          </Button>
        </div>
        
        {/* Painel de filtros para dispositivos móveis */}
        {showMobileFilters && (
          <div className="fixed inset-0 bg-black bg-opacity-50 z-50 md:hidden">
            <div className="bg-white h-full w-full max-w-sm ml-auto p-4 overflow-y-auto">
              <div className="flex justify-between items-center mb-4">
                <h2 className="font-semibold text-lg">Filtros</h2>
                <Button 
                  variant="ghost" 
                  onClick={() => setShowMobileFilters(false)}
                >
                  <X size={20} />
                </Button>
              </div>
              
              <Accordion type="multiple" defaultValue={["categories", "price", "stock"]} className="space-y-2">
                {/* Categorias para dispositivos móveis */}
                <AccordionItem value="categories" className="border-b">
                  <AccordionTrigger className="text-base font-medium">
                    Categorias
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-2 pt-1">
                      {availableCategories.map((category) => (
                        <div key={category} className="flex items-center space-x-2">
                          <Checkbox 
                            id={`mobile-category-${category}`} 
                            checked={selectedCategories.includes(category)}
                            onCheckedChange={(checked) => 
                              handleCategoryChange(category, checked as boolean)
                            }
                          />
                          <label 
                            htmlFor={`mobile-category-${category}`}
                            className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                          >
                            {category}
                          </label>
                        </div>
                      ))}
                    </div>
                  </AccordionContent>
                </AccordionItem>
                
                {/* Faixa de preço para dispositivos móveis */}
                <AccordionItem value="price" className="border-b">
                  <AccordionTrigger className="text-base font-medium">
                    Preço
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-6">
                      <Slider
                        min={0}
                        max={1000}
                        step={10}
                        value={priceRange}
                        onValueChange={(value) => setPriceRange(value as [number, number])}
                        className="my-6"
                      />
                      <div className="flex items-center justify-between">
                        <div className="bg-gray-100 rounded-md px-2 py-1">
                          <span className="text-xs text-gray-500">R$</span>
                          <span className="text-sm font-medium ml-1">{priceRange[0]}</span>
                        </div>
                        <div className="bg-gray-100 rounded-md px-2 py-1">
                          <span className="text-xs text-gray-500">R$</span>
                          <span className="text-sm font-medium ml-1">{priceRange[1]}</span>
                        </div>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                
                {/* Disponibilidade para dispositivos móveis */}
                <AccordionItem value="stock" className="border-b">
                  <AccordionTrigger className="text-base font-medium">
                    Disponibilidade
                  </AccordionTrigger>
                  <AccordionContent>
                    <div className="flex items-center space-x-2">
                      <Checkbox 
                        id="mobile-inStock" 
                        checked={inStockOnly}
                        onCheckedChange={(checked) => setInStockOnly(!!checked)}
                      />
                      <label 
                        htmlFor="mobile-inStock"
                        className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                      >
                        Apenas produtos em estoque
                      </label>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
              
              <div className="mt-8 space-y-4">
                <Button 
                  className="w-full bg-green-600 hover:bg-green-700"
                  onClick={() => setShowMobileFilters(false)}
                >
                  Ver {filteredProducts.length} produtos
                </Button>
                
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={() => {
                    handleClearFilters();
                    setShowMobileFilters(false);
                  }}
                >
                  Limpar filtros
                </Button>
              </div>
            </div>
          </div>
        )}
        
        {/* Lista de produtos filtrados */}
        <div className="flex-grow">
          {/* Mostrar filtros aplicados */}
          {(selectedCategories.length > 0 || searchQuery || inStockOnly || priceRange[0] > 0 || priceRange[1] < 1000) && (
            <div className="mb-4 flex flex-wrap gap-2 items-center">
              <span className="text-sm text-gray-500">Filtros aplicados:</span>
              
              {searchQuery && (
                <Badge variant="outline" className="flex items-center gap-1">
                  Termo: {searchQuery}
                  <button onClick={() => setSearchQuery("")} className="ml-1">
                    <X size={14} />
                  </button>
                </Badge>
              )}
              
              {selectedCategories.map((category) => (
                <Badge key={category} variant="outline" className="flex items-center gap-1">
                  {category}
                  <button onClick={() => handleCategoryChange(category, false)} className="ml-1">
                    <X size={14} />
                  </button>
                </Badge>
              ))}
              
              {(priceRange[0] > 0 || priceRange[1] < 1000) && (
                <Badge variant="outline" className="flex items-center gap-1">
                  Preço: R${priceRange[0]} - R${priceRange[1]}
                  <button onClick={() => setPriceRange([0, 1000])} className="ml-1">
                    <X size={14} />
                  </button>
                </Badge>
              )}
              
              {inStockOnly && (
                <Badge variant="outline" className="flex items-center gap-1">
                  Em estoque
                  <button onClick={() => setInStockOnly(false)} className="ml-1">
                    <X size={14} />
                  </button>
                </Badge>
              )}
              
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={handleClearFilters}
                className="text-xs text-gray-500 hover:text-gray-700"
              >
                Limpar todos
              </Button>
            </div>
          )}
          
          {/* Resultados da pesquisa */}
          <div>
            <div className="flex justify-between items-center mb-4">
              <p className="text-gray-600">
                {isLoadingProducts ? (
                  "Carregando produtos..."
                ) : (
                  `${filteredProducts.length} ${filteredProducts.length === 1 ? 'produto encontrado' : 'produtos encontrados'}`
                )}
              </p>
            </div>
            
            {isLoadingProducts ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {[...Array(8)].map((_, i) => (
                  <div key={i} className="animate-pulse">
                    <div className="bg-gray-200 rounded-md h-40 mb-2"></div>
                    <div className="bg-gray-200 rounded h-4 mb-2 w-3/4"></div>
                    <div className="bg-gray-200 rounded h-4 w-1/2"></div>
                  </div>
                ))}
              </div>
            ) : filteredProducts.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-lg shadow">
                <div className="mb-4">
                  <SearchIcon size={48} className="mx-auto text-gray-300" />
                </div>
                <h3 className="text-lg font-semibold mb-2">Nenhum resultado encontrado</h3>
                <p className="text-gray-500 mb-4">
                  Tente ajustar seus filtros ou usar termos de busca diferentes.
                </p>
                <Button 
                  variant="outline"
                  onClick={handleClearFilters}
                >
                  Limpar filtros
                </Button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {filteredProducts.map((product) => (
                  <ProductCard 
                    key={product.id} 
                    product={product} 
                    variant={product.isPromoted ? "promotion" : "bestseller"}
                  />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}