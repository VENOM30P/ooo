import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useCart } from "@/hooks/useCart";
import { Button } from "@/components/ui/button";
import { Trash2, Plus, Minus, ShoppingBag, ArrowLeft } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function Cart() {
  const { items, removeFromCart, updateQuantity, totalPrice, clearCart } = useCart();
  const { toast } = useToast();
  const [isCheckingOut, setIsCheckingOut] = useState(false);

  const [, navigate] = useLocation();

  const handleCheckout = () => {
    setIsCheckingOut(true);

    // Simulate checkout process
    setTimeout(() => {
      clearCart();
      setIsCheckingOut(false);
      navigate("/resumo");
      toast({
        title: "Pedido realizado com sucesso!",
        description: "Seu pedido foi processado e está sendo preparado para envio.",
        variant: "default",
      });
    }, 1500);
  };

  if (items.length === 0) {
    return (
      <div className="container mx-auto px-4 py-16 max-w-5xl">
        <h1 className="text-3xl font-bold mb-8">Seu Carrinho</h1>
        <div className="bg-white rounded-lg shadow-md p-8 text-center">
          <div className="flex justify-center mb-4">
            <ShoppingBag size={64} className="text-gray-300" />
          </div>
          <h2 className="text-2xl font-semibold mb-2">Seu carrinho está vazio</h2>
          <p className="text-gray-500 mb-6">
            Parece que você ainda não adicionou nenhum item ao seu carrinho.
          </p>
          <Link href="/" className="inline-block bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-6 rounded-md transition-colors">
            Continuar Comprando
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="flex items-center mb-6">
        <Link href="/" className="flex items-center text-gray-600 hover:text-gray-900 mr-4">
          <ArrowLeft size={20} className="mr-1" />
          <span>Continuar Comprando</span>
        </Link>
        <h1 className="text-3xl font-bold">Seu Carrinho</h1>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        <div className="lg:w-2/3">
          <div className="bg-white rounded-lg shadow-md overflow-hidden mb-4">
            <table className="w-full">
              <thead className="bg-gray-50 border-b">
                <tr>
                  <th className="py-4 px-6 text-left">Produto</th>
                  <th className="py-4 px-6 text-center">Quantidade</th>
                  <th className="py-4 px-6 text-right">Preço</th>
                  <th className="py-4 px-6 text-right">Subtotal</th>
                  <th className="py-4 px-6 text-center">Ações</th>
                </tr>
              </thead>
              <tbody>
                {items.map((item) => (
                  <tr key={item.id} className="border-b">
                    <td className="py-4 px-6">
                      <div className="flex items-center">
                        <img
                          src={item.imageUrl}
                          alt={item.name}
                          className="w-16 h-16 object-cover rounded mr-4"
                        />
                        <div>
                          <p className="font-semibold">{item.name}</p>
                          <p className="text-sm text-gray-500">{item.category}</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center justify-center">
                        <button
                          onClick={() => updateQuantity(item.id, Math.max(1, item.quantity - 1))}
                          className="p-1 rounded-full border hover:bg-gray-100"
                        >
                          <Minus size={16} />
                        </button>
                        <span className="mx-3 w-8 text-center">{item.quantity}</span>
                        <button
                          onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          className="p-1 rounded-full border hover:bg-gray-100"
                        >
                          <Plus size={16} />
                        </button>
                      </div>
                    </td>
                    <td className="py-4 px-6 text-right">
                      <span>R$ {(item.price || 0).toFixed(2)}</span>
                      {item.originalPrice && item.price && item.originalPrice > item.price && (
                        <span className="text-sm text-gray-400 line-through block">
                          R$ {(item.originalPrice || 0).toFixed(2)}
                        </span>
                      )}
                    </td>
                    <td className="py-4 px-6 text-right font-semibold">
                      R$ {((item.price || 0) * item.quantity).toFixed(2)}
                    </td>
                    <td className="py-4 px-6 text-center">
                      <button
                        onClick={() => removeFromCart(item.id)}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 size={20} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="lg:w-1/3">
          <div className="bg-white rounded-lg shadow-md p-6">
            <h2 className="text-xl font-bold mb-4">Resumo do Pedido</h2>

            <div className="border-t border-b py-3 mb-4">
              <div className="flex justify-between mb-2">
                <span>Subtotal</span>
                <span>R$ {(totalPrice || 0).toFixed(2)}</span>
              </div>
              <div className="flex justify-between mb-2">
                <span>Frete</span>
                <span className="text-green-600">Grátis</span>
              </div>
            </div>

            <div className="flex justify-between mb-6">
              <span className="font-bold">Total</span>
              <span className="font-bold text-xl">R$ {(totalPrice || 0).toFixed(2)}</span>
            </div>

            <Button 
              className="w-full bg-green-600 hover:bg-green-700"
              disabled={isCheckingOut}
              onClick={handleCheckout}
            >
              {isCheckingOut ? "Processando..." : "Finalizar Compra"}
            </Button>

            <div className="mt-4">
              <button
                onClick={clearCart}
                className="text-sm text-gray-500 hover:text-red-600 flex items-center justify-center w-full"
              >
                <Trash2 size={16} className="mr-1" />
                Limpar Carrinho
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}