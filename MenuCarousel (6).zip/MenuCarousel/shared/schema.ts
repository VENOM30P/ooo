import { pgTable, text, serial, integer, boolean, doublePrecision, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Products Table
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").notNull(),
  price: doublePrecision("price").notNull(),
  originalPrice: doublePrecision("original_price").notNull(),
  imageUrl: text("image_url").notNull(),
  category: text("category").notNull(),
  inStock: boolean("in_stock").notNull().default(true),
  isPromoted: boolean("is_promoted").notNull().default(false),
  isBestSeller: boolean("is_bestseller").notNull().default(false),
});

export const insertProductSchema = createInsertSchema(products).pick({
  name: true,
  description: true,
  price: true,
  originalPrice: true,
  imageUrl: true,
  category: true,
  inStock: true,
  isPromoted: true,
  isBestSeller: true,
});

// Cart Items Table
export const cartItems = pgTable("cart_items", {
  id: serial("id").primaryKey(),
  productId: integer("product_id").notNull(),
  sessionId: text("session_id").notNull(),
  quantity: integer("quantity").notNull().default(1),
});

export const insertCartItemSchema = createInsertSchema(cartItems).pick({
  productId: true,
  sessionId: true,
  quantity: true,
});

// Motivational Slides Table
export const motivationalSlides = pgTable("motivational_slides", {
  id: serial("id").primaryKey(),
  imageUrl: text("image_url").notNull(),
  quote: text("quote").notNull(),
});

export const insertMotivationalSlideSchema = createInsertSchema(motivationalSlides).pick({
  imageUrl: true,
  quote: true,
});

// Story Slides Table
export const storySlides = pgTable("story_slides", {
  id: serial("id").primaryKey(),
  imageUrl: text("image_url").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
});

export const insertStorySlideSchema = createInsertSchema(storySlides).pick({
  imageUrl: true,
  title: true,
  description: true,
});

// Users Table (keeping for authentication if needed)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  isAdmin: boolean("is_admin").notNull().default(false),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  isAdmin: true,
});

// Logs Table
export const logs = pgTable("logs", {
  id: serial("id").primaryKey(),
  level: text("level").notNull(), // 'info', 'warn', 'error'
  category: text("category").notNull(), // 'auth', 'product', 'user', 'cart', etc
  message: text("message").notNull(),
  details: text("details"), // JSON stringified details
  userId: integer("user_id"), // opcional, para logs relacionados a usuários
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  ipAddress: text("ip_address"),
  userAgent: text("user_agent"),
  path: text("path"),
});

export const insertLogSchema = createInsertSchema(logs).pick({
  level: true,
  category: true,
  message: true,
  details: true,
  userId: true,
  ipAddress: true,
  userAgent: true,
  path: true,
});

// Export Types
export type Product = typeof products.$inferSelect;
export type InsertProduct = z.infer<typeof insertProductSchema>;

export type CartItem = typeof cartItems.$inferSelect;
export type InsertCartItem = z.infer<typeof insertCartItemSchema>;

export type MotivationalSlide = typeof motivationalSlides.$inferSelect;
export type InsertMotivationalSlide = z.infer<typeof insertMotivationalSlideSchema>;

export type StorySlide = typeof storySlides.$inferSelect;
export type InsertStorySlide = z.infer<typeof insertStorySlideSchema>;

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Log = typeof logs.$inferSelect;
export type InsertLog = z.infer<typeof insertLogSchema>;

// Define Collection type for the SpecialCollections component
export type Collection = {
  id: number;
  name: string;
  imageUrl: string;
  description: string;
};