import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { v4 as uuidv4 } from "uuid";
import { insertProductSchema } from "../shared/schema";
import { hashPassword, comparePasswords, generateToken, verifyToken } from './utils/auth';
import { logger } from './utils/logger';
import { requestLoggerMiddleware } from './middleware/requestLogger';

// Helper to get session ID for cart
function getSessionId(req: Request): string {
  // Check for existing session ID in cookie
  let sessionId = req.cookies?.cart_session_id;

  // If no session ID, create a new one
  if (!sessionId) {
    sessionId = uuidv4();
    // This would normally set a cookie, but we'll rely on the client keeping the ID
  }

  return sessionId;
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Adicionar middleware de log para todas as requisições
  app.use(requestLoggerMiddleware);

  // Rota para login
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;

      if (!username || !password) {
        logger.warn({
          category: 'auth',
          message: 'Tentativa de login com dados incompletos',
          request: req
        });
        return res.status(400).json({ message: "Nome de usuário e senha são obrigatórios" });
      }

      const user = await storage.getUserByUsername(username);
      if (!user) {
        logger.warn({
          category: 'auth',
          message: 'Tentativa de login com usuário inexistente',
          details: { username },
          request: req
        });
        return res.status(401).json({ message: "Credenciais inválidas" });
      }

      const isPasswordValid = await comparePasswords(password, user.password);
      if (!isPasswordValid) {
        logger.warn({
          category: 'auth',
          message: 'Tentativa de login com senha incorreta',
          details: { username },
          request: req
        });
        return res.status(401).json({ message: "Credenciais inválidas" });
      }

      const token = generateToken(user);
      const { password: _, ...userWithoutPassword } = user;

      logger.info({
        category: 'auth',
        message: 'Login realizado com sucesso',
        userId: user.id,
        request: req
      });

      res.json({
        user: userWithoutPassword,
        token
      });
    } catch (error) {
      logger.error({
        category: 'auth',
        message: 'Erro no processo de login',
        details: { error },
        request: req
      });
      res.status(500).json({ message: "Erro no servidor" });
    }
  });

  // Rota para registro
  app.post("/api/auth/register", async (req, res) => {
    try {
      const { username, password } = req.body;

      if (!username || !password) {
        logger.warn({ category: 'auth', message: 'Tentativa de registro com dados incompletos', request: req });
        return res.status(400).json({ message: "Nome de usuário e senha são obrigatórios" });
      }

      // Verificar se o usuário já existe
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        logger.warn({ category: 'auth', message: 'Tentativa de registro com usuário existente', details: { username }, request: req });
        return res.status(409).json({ message: "Este nome de usuário já está em uso" });
      }

      // Hash da senha antes de salvar
      const hashedPassword = await hashPassword(password);

      // Criar novo usuário
      const newUser = await storage.createUser({
        username,
        password: hashedPassword,
        isAdmin: false
      });

      const token = generateToken(newUser);
      const { password: _, ...userWithoutPassword } = newUser;

      logger.info({ category: 'auth', message: 'Usuário registrado com sucesso', userId: newUser.id, request: req });

      res.status(201).json({
        user: userWithoutPassword,
        token
      });
    } catch (error) {
      logger.error({ category: 'auth', message: 'Erro no processo de registro', details: { error }, request: req });
      res.status(500).json({ message: "Erro no servidor" });
    }
  });

  // Middleware de autenticação
  const authenticateToken = async (req: Request, res: Response, next: Function) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
      logger.warn({ category: 'auth', message: 'Requisição sem token de autenticação', request: req });
      return res.status(401).json({ message: "Token não fornecido" });
    }

    try {
      const decoded = verifyToken(token);
      (req as any).user = decoded;
      next();
    } catch (error) {
      logger.warn({ category: 'auth', message: 'Token de autenticação inválido', details: { error }, request: req });
      return res.status(403).json({ message: "Token inválido" });
    }
  };

  // Rota protegida para perfil do usuário
  app.get("/api/users/profile", authenticateToken, async (req: Request, res: Response) => {
    try {
      const userId = (req as any).user.id;
      const user = await storage.getUser(userId);

      if (!user) {
        logger.warn({ category: 'users', message: 'Usuário não encontrado', details: { userId }, request: req });
        return res.status(404).json({ message: "Usuário não encontrado" });
      }

      const { password: _, ...userWithoutPassword } = user;
      logger.info({ category: 'users', message: 'Perfil do usuário recuperado com sucesso', userId, request: req });
      res.json(userWithoutPassword);
    } catch (error) {
      logger.error({ category: 'users', message: 'Erro ao buscar perfil de usuário', details: { error }, request: req });
      res.status(500).json({ message: "Erro no servidor" });
    }
  });


// Rotas para gerenciamento de usuários
app.get("/api/users", authenticateToken, async (req, res) => {
  try {
    logger.info({ category: 'users', message: 'Recuperando lista de usuários', request: req });
    const users = await storage.getAllUsers();
    res.json(users);
  } catch (error) {
    logger.error({ category: 'users', message: 'Erro ao buscar usuários', details: { error }, request: req });
    res.status(500).json({ error: "Erro ao buscar usuários" });
  }
});

// Rota para registro de novo usuário
app.post("/api/users/register", authenticateToken, async (req, res) => {
  try {
    const { username, password, isAdmin } = req.body;
    
    // Validação básica
    if (!username || !password) {
      logger.warn({ category: 'users', message: 'Tentativa de registro de usuário com dados incompletos', request: req });
      return res.status(400).json({ message: "Nome de usuário e senha são obrigatórios" });
    }
    
    // Verificar se o usuário já existe
    const existingUsers = await storage.getAllUsers();
    const userExists = existingUsers.some(user => user.username === username);
    
    if (userExists) {
      logger.warn({ category: 'users', message: 'Tentativa de registro de usuário existente', details: { username }, request: req });
      return res.status(409).json({ message: "Este nome de usuário já está em uso" });
    }
    
    // Criar novo usuário
    const newUser = await storage.createUser({
      username,
      password,
      isAdmin: isAdmin || false
    });
    
    logger.info({ category: 'users', message: 'Novo usuário registrado', details: { userId: newUser.id }, request: req });
    
    // Retornar usuário sem a senha
    const { password: _, ...userWithoutPassword } = newUser;
    res.status(201).json(userWithoutPassword);
  } catch (error) {
    logger.error({ category: 'users', message: 'Erro ao registrar usuário', details: { error }, request: req });
    res.status(500).json({ message: "Erro ao registrar usuário" });
  }
});

// Rota para promover usuário a administrador
app.patch("/api/users/:id/promote", authenticateToken, async (req, res) => {
  try {
    // Verificar token especial no cabeçalho para identificar o admin exclusivo
    const adminToken = req.headers['x-admin-token'];
    if (adminToken !== 'meuAdminEspecial') {
      logger.warn({ category: 'users', message: 'Tentativa de promoção de usuário sem token de administrador', request: req });
      return res.status(403).json({ message: "Acesso não autorizado" });
    }
    
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      logger.warn({ category: 'users', message: 'ID de usuário inválido para promoção', request: req });
      return res.status(400).json({ message: "ID de usuário inválido" });
    }
    
    const updatedUser = await storage.promoteUser(id);
    if (!updatedUser) {
      logger.warn({ category: 'users', message: 'Usuário não encontrado para promoção', details: { id }, request: req });
      return res.status(404).json({ message: "Usuário não encontrado" });
    }
    
    logger.info({ category: 'users', message: 'Usuário promovido com sucesso', details: { userId: id }, request: req });
    res.json(updatedUser);
  } catch (error) {
    logger.error({ category: 'users', message: 'Erro ao promover usuário', details: { error }, request: req });
    res.status(500).json({ error: "Erro ao promover usuário" });
  }
});

// Rota para excluir usuário
app.delete("/api/users/:id", authenticateToken, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    if (isNaN(id)) {
      logger.warn({ category: 'users', message: 'ID de usuário inválido para exclusão', request: req });
      return res.status(400).json({ message: "ID de usuário inválido" });
    }
    
    const success = await storage.deleteUser(id);
    if (!success) {
      logger.warn({ category: 'users', message: 'Usuário não encontrado para exclusão', details: { id }, request: req });
      return res.status(404).json({ message: "Usuário não encontrado" });
    }
    
    logger.info({ category: 'users', message: 'Usuário excluído com sucesso', details: { userId: id }, request: req });
    res.json({ success: true, message: "Usuário excluído com sucesso" });
  } catch (error) {
    logger.error({ category: 'users', message: 'Erro ao excluir usuário', details: { error }, request: req });
    res.status(500).json({ error: "Erro ao excluir usuário" });
  }
});


// Product Routes
app.get("/api/products", async (req: Request, res: Response) => {
  logger.info({ category: 'products', message: 'Recuperando lista de produtos', request: req });
  const products = await storage.getProducts();
  res.json(products);
});

app.get("/api/products/promotions", async (req: Request, res: Response) => {
  logger.info({ category: 'products', message: 'Recuperando produtos em promoção', request: req });
  const products = await storage.getPromotedProducts();
  res.json(products);
});

app.get("/api/products/bestsellers", async (req: Request, res: Response) => {
  logger.info({ category: 'products', message: 'Recuperando produtos mais vendidos', request: req });
  const products = await storage.getBestSellerProducts();
  res.json(products);
});

app.get("/api/products/:id", async (req: Request, res: Response) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) {
    logger.warn({ category: 'products', message: 'ID de produto inválido', request: req });
    return res.status(400).json({ message: "Invalid product ID" });
  }
  
  logger.info({ category: 'products', message: 'Recuperando produto pelo ID', details: { productId: id }, request: req });
  const product = await storage.getProductById(id);
  if (!product) {
    logger.warn({ category: 'products', message: 'Produto não encontrado', details: { productId: id }, request: req });
    return res.status(404).json({ message: "Product not found" });
  }
  
  res.json(product);
});

// Cart Routes
app.get("/api/cart", async (req: Request, res: Response) => {
  const sessionId = getSessionId(req);
  logger.info({ category: 'cart', message: 'Recuperando itens do carrinho', details: { sessionId }, request: req });
  const cartItems = await storage.getCartItems(sessionId);
  
  // Fetch full product details for each cart item
  const cartItemsWithProducts = await Promise.all(
    cartItems.map(async (item) => {
      const product = await storage.getProductById(item.productId);
      return {
        ...item,
        product
      };
    })
  );
  
  res.json(cartItemsWithProducts);
});

app.post("/api/cart", async (req: Request, res: Response) => {
  const sessionId = getSessionId(req);
  
  // Validate request body
  const schema = z.object({
    productId: z.number(),
    quantity: z.number().optional().default(1)
  });
  
  try {
    const { productId, quantity } = schema.parse(req.body);
    
    // Verify product exists
    const product = await storage.getProductById(productId);
    if (!product) {
      logger.warn({ category: 'cart', message: 'Produto não encontrado para adicionar ao carrinho', details: { productId }, request: req });
      return res.status(404).json({ message: "Product not found" });
    }
    
    // Check if product is already in cart
    const existingCartItems = await storage.getCartItems(sessionId);
    const existingItem = existingCartItems.find(item => item.productId === productId);
    
    if (existingItem) {
      // Update quantity if already in cart
      const updatedItem = await storage.updateCartItemQuantity(
        existingItem.id, 
        existingItem.quantity + quantity
      );
      logger.info({ category: 'cart', message: 'Quantidade de item no carrinho atualizada', details: { cartItemId: existingItem.id }, request: req });
      return res.json(updatedItem);
    } else {
      // Add new item to cart
      const newCartItem = await storage.createCartItem({
        productId,
        sessionId,
        quantity
      });
      logger.info({ category: 'cart', message: 'Novo item adicionado ao carrinho', details: { cartItemId: newCartItem.id }, request: req });
      return res.json(newCartItem);
    }
  } catch (error) {
    logger.error({ category: 'cart', message: 'Erro ao adicionar item ao carrinho', details: { error }, request: req });
    return res.status(400).json({ message: "Invalid request body" });
  }
});

app.patch("/api/cart/:id", async (req: Request, res: Response) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) {
    logger.warn({ category: 'cart', message: 'ID de item de carrinho inválido para atualização', request: req });
    return res.status(400).json({ message: "Invalid cart item ID" });
  }
  
  // Validate request body
  const schema = z.object({
    quantity: z.number().min(1)
  });
  
  try {
    const { quantity } = schema.parse(req.body);
    
    const updatedItem = await storage.updateCartItemQuantity(id, quantity);
    if (!updatedItem) {
      logger.warn({ category: 'cart', message: 'Item de carrinho não encontrado para atualização', details: { cartItemId: id }, request: req });
      return res.status(404).json({ message: "Cart item not found" });
    }
    
    logger.info({ category: 'cart', message: 'Item de carrinho atualizado', details: { cartItemId: id }, request: req });
    res.json(updatedItem);
  } catch (error) {
    logger.error({ category: 'cart', message: 'Erro ao atualizar item de carrinho', details: { error }, request: req });
    return res.status(400).json({ message: "Invalid request body" });
  }
});

app.delete("/api/cart/:id", async (req: Request, res: Response) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) {
    logger.warn({ category: 'cart', message: 'ID de item de carrinho inválido para exclusão', request: req });
    return res.status(400).json({ message: "Invalid cart item ID" });
  }
  
  const success = await storage.deleteCartItem(id);
  if (!success) {
    logger.warn({ category: 'cart', message: 'Item de carrinho não encontrado para exclusão', details: { cartItemId: id }, request: req });
    return res.status(404).json({ message: "Cart item not found" });
  }
  
  logger.info({ category: 'cart', message: 'Item de carrinho excluído', details: { cartItemId: id }, request: req });
  res.json({ success: true });
});

// Slider Routes
app.get("/api/motivational-slides", async (req: Request, res: Response) => {
  logger.info({ category: 'slides', message: 'Recuperando slides motivacionais', request: req });
  const slides = await storage.getMotivationalSlides();
  res.json(slides);
});

app.get("/api/story-slides", async (req: Request, res: Response) => {
  logger.info({ category: 'slides', message: 'Recuperando slides de histórias', request: req });
  const slides = await storage.getStorySlides();
  res.json(slides);
});


// Admin Product Management Routes
app.post("/api/products", authenticateToken, async (req: Request, res: Response) => {
  try {
    // Validar os dados do produto
    const productData = insertProductSchema.parse(req.body);
    
    // Criar o produto
    const newProduct = await storage.createProduct(productData);
    
    logger.info({ category: 'products', message: 'Novo produto criado', details: { productId: newProduct.id }, request: req });
    res.status(201).json(newProduct);
  } catch (error) {
    if (error instanceof z.ZodError) {
      logger.warn({ category: 'products', message: 'Dados de produto inválidos', details: { errors: error.errors }, request: req });
      return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
    }
    logger.error({ category: 'products', message: 'Erro ao criar produto', details: { error }, request: req });
    res.status(500).json({ message: "Erro ao criar produto" });
  }
});

app.patch("/api/products/:id", authenticateToken, async (req: Request, res: Response) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) {
    logger.warn({ category: 'products', message: 'ID de produto inválido para atualização', request: req });
    return res.status(400).json({ message: "ID de produto inválido" });
  }
  
  try {
    // Verificar se o produto existe
    const existingProduct = await storage.getProductById(id);
    if (!existingProduct) {
      logger.warn({ category: 'products', message: 'Produto não encontrado para atualização', details: { productId: id }, request: req });
      return res.status(404).json({ message: "Produto não encontrado" });
    }
    
    // Validar os dados do produto
    const productData = insertProductSchema.parse(req.body);
    
    // Atualizar o produto
    const updatedProduct = await storage.updateProduct(id, productData);
    
    logger.info({ category: 'products', message: 'Produto atualizado com sucesso', details: { productId: id }, request: req });
    res.json(updatedProduct);
  } catch (error) {
    if (error instanceof z.ZodError) {
      logger.warn({ category: 'products', message: 'Dados de produto inválidos na atualização', details: { errors: error.errors }, request: req });
      return res.status(400).json({ message: "Dados inválidos", errors: error.errors });
    }
    logger.error({ category: 'products', message: 'Erro ao atualizar produto', details: { error }, request: req });
    res.status(500).json({ message: "Erro ao atualizar produto" });
  }
});

app.delete("/api/products/:id", authenticateToken, async (req: Request, res: Response) => {
  const id = parseInt(req.params.id);
  if (isNaN(id)) {
    logger.warn({ category: 'products', message: 'ID de produto inválido para exclusão', request: req });
    return res.status(400).json({ message: "ID de produto inválido" });
  }
  
  try {
    // Verificar se o produto existe
    const existingProduct = await storage.getProductById(id);
    if (!existingProduct) {
      logger.warn({ category: 'products', message: 'Produto não encontrado para exclusão', details: { productId: id }, request: req });
      return res.status(404).json({ message: "Produto não encontrado" });
    }
    
    // Excluir o produto
    const success = await storage.deleteProduct(id);
    
    if (success) {
      logger.info({ category: 'products', message: 'Produto excluído com sucesso', details: { productId: id }, request: req });
      res.json({ success: true, message: "Produto excluído com sucesso" });
    } else {
      logger.error({ category: 'products', message: 'Erro ao excluir produto', details: { productId: id }, request: req });
      res.status(500).json({ success: false, message: "Erro ao excluir produto" });
    }
  } catch (error) {
    logger.error({ category: 'products', message: 'Erro ao excluir produto', details: { error }, request: req });
    res.status(500).json({ message: "Erro ao excluir produto" });
  }
});

const httpServer = createServer(app);
return httpServer;
}