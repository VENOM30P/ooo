import pg from 'pg';
import { drizzle } from 'drizzle-orm/node-postgres';
import * as schema from "@shared/schema";

const { Pool } = pg;

// Usando pg padrão em vez de serverless para maior estabilidade

if (!process.env.DATABASE_URL) {
  throw new Error(
    "DATABASE_URL must be set. Did you forget to provision a database?",
  );
}

// Flag para controlar o estado da conexão
let isConnected = false;

// Cria uma função para obter o pool de conexão com configurações otimizadas
const createPool = () => {
  try {
    return new Pool({ 
      connectionString: process.env.DATABASE_URL,
      max: 3,
      idleTimeoutMillis: 30000,
      connectionTimeoutMillis: 5000,
      allowExitOnIdle: false,
      statement_timeout: 10000,
      query_timeout: 10000,
      keepAlive: true,
      keepAliveInitialDelayMillis: 5000,
      retry_strategy: {
        retries: 5,
        factor: 2,
        minTimeout: 1000,
        maxTimeout: 5000
      }
    });
  } catch (error) {
    console.error('Erro ao criar pool de conexão:', error);
    throw error;
  }
};

// Pool inicial
export let pool = createPool();
export let db = drizzle({ client: pool, schema });

// Função para reconectar ao banco de dados com retentativas
export async function reconnectDatabase(maxRetries = 5, delayMs = 3000) {
  let retries = 0;
  
  // Tenta fechar a conexão existente
  try {
    if (pool) {
      await pool.end();
      console.log('Pool antigo fechado com sucesso');
    }
  } catch (err) {
    console.warn('Erro ao fechar pool antigo, continuando mesmo assim:', 
      err instanceof Error ? err.message : String(err));
  }
  
  // Cria novo pool
  try {
    console.log('Criando novo pool de conexão...');
    pool = createPool();
    db = drizzle({ client: pool, schema });
    
    // Tenta executar uma consulta simples para testar a conexão
    const result = await pool.query('SELECT 1 as connected');
    
    if (result && result.rows && result.rows[0] && result.rows[0].connected === 1) {
      isConnected = true;
      notifyDatabaseReady();
      console.log('Reconexão bem-sucedida!');
      return true;
    }
    
    throw new Error('Teste de conexão falhou');
  } catch (error) {
    console.error('Falha na primeira tentativa de reconexão:', 
      error instanceof Error ? error.message : String(error));
    
    // Se falhar na primeira tentativa, inicia o processo de retry
    while (retries < maxRetries) {
      retries++;
      console.log(`Tentativa ${retries}/${maxRetries} em ${delayMs}ms...`);
      
      await new Promise(resolve => setTimeout(resolve, delayMs));
      
      try {
        pool = createPool();
        db = drizzle({ client: pool, schema });
        
        const result = await pool.query('SELECT 1 as connected');
        
        if (result && result.rows && result.rows[0] && result.rows[0].connected === 1) {
          isConnected = true;
          notifyDatabaseReady();
          console.log(`Reconexão bem-sucedida na tentativa ${retries}!`);
          return true;
        }
      } catch (retryError) {
        console.error(`Falha na tentativa ${retries}:`, 
          retryError instanceof Error ? retryError.message : String(retryError));
        
        // Aumenta o intervalo para a próxima tentativa (backoff exponencial)
        delayMs = Math.min(delayMs * 1.5, 15000);
      }
    }
    
    console.error(`Todas as ${maxRetries} tentativas de reconexão falharam.`);
    return false;
  }
}

// Declaramos uma função que será atribuída mais tarde para evitar dependência circular
let notifyDatabaseReady: () => void = () => {
  console.log('Database is ready but no logger registered yet.');
};

// Função para registrar o callback quando o logger é carregado
export function registerDatabaseReadyCallback(callback: () => void) {
  notifyDatabaseReady = callback;
}

export async function initializeDatabase() {
  try {
    console.log('Initializing database...');
    
    // Check if logs table exists
    const checkTablesQuery = `
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public' 
        AND table_name = 'logs'
      );
    `;
    
    const tablesExistResult = await pool.query(checkTablesQuery);
    const tablesExist = tablesExistResult.rows[0].exists;
    
    if (!tablesExist) {
      console.log('Creating database tables...');
      
      // Create all tables from schema
      const createProductsTable = `
        CREATE TABLE IF NOT EXISTS products (
          id SERIAL PRIMARY KEY,
          name TEXT NOT NULL,
          description TEXT NOT NULL,
          price DOUBLE PRECISION NOT NULL,
          original_price DOUBLE PRECISION NOT NULL,
          image_url TEXT NOT NULL,
          category TEXT NOT NULL,
          in_stock BOOLEAN NOT NULL DEFAULT TRUE,
          is_promoted BOOLEAN NOT NULL DEFAULT FALSE,
          is_bestseller BOOLEAN NOT NULL DEFAULT FALSE
        );
      `;
      
      const createCartItemsTable = `
        CREATE TABLE IF NOT EXISTS cart_items (
          id SERIAL PRIMARY KEY,
          product_id INTEGER NOT NULL,
          session_id TEXT NOT NULL,
          quantity INTEGER NOT NULL DEFAULT 1
        );
      `;
      
      const createMotivationalSlidesTable = `
        CREATE TABLE IF NOT EXISTS motivational_slides (
          id SERIAL PRIMARY KEY,
          image_url TEXT NOT NULL,
          quote TEXT NOT NULL
        );
      `;
      
      const createStorySlidesTable = `
        CREATE TABLE IF NOT EXISTS story_slides (
          id SERIAL PRIMARY KEY,
          image_url TEXT NOT NULL,
          title TEXT NOT NULL,
          description TEXT NOT NULL
        );
      `;
      
      const createUsersTable = `
        CREATE TABLE IF NOT EXISTS users (
          id SERIAL PRIMARY KEY,
          username TEXT NOT NULL UNIQUE,
          password TEXT NOT NULL,
          is_admin BOOLEAN NOT NULL DEFAULT FALSE
        );
      `;
      
      const createLogsTable = `
        CREATE TABLE IF NOT EXISTS logs (
          id SERIAL PRIMARY KEY,
          level TEXT NOT NULL,
          category TEXT NOT NULL,
          message TEXT NOT NULL,
          details TEXT,
          user_id INTEGER,
          timestamp TIMESTAMP NOT NULL DEFAULT NOW(),
          ip_address TEXT,
          user_agent TEXT,
          path TEXT
        );
      `;
      
      // Execute the create table queries
      await pool.query(createProductsTable);
      await pool.query(createCartItemsTable);
      await pool.query(createMotivationalSlidesTable);
      await pool.query(createStorySlidesTable);
      await pool.query(createUsersTable);
      await pool.query(createLogsTable);
      
      console.log('Database tables created successfully!');
    } else {
      console.log('Database tables already exist.');
    }
    
    console.log('Database initialization completed.');
    
    // Notifica que o banco de dados está pronto
    notifyDatabaseReady();
    
  } catch (error) {
    console.error('Error initializing database:', error);
    throw error;
  }
}
