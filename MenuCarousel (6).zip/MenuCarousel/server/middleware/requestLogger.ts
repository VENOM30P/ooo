import { Request, Response, NextFunction } from 'express';
import { logger } from '../utils/logger';

export async function requestLoggerMiddleware(req: Request, res: Response, next: NextFunction) {
  const startTime = Date.now();

  // Interceptar a finalização da resposta
  res.on('finish', () => {
    const duration = Date.now() - startTime;
    const userId = (req as any).user?.id;

    logger.info({
      category: 'system',
      message: `${req.method} ${req.path} - ${res.statusCode}`,
      details: {
        method: req.method,
        path: req.path,
        statusCode: res.statusCode,
        duration: `${duration}ms`,
        query: req.query,
        body: req.method !== 'GET' ? req.body : undefined,
      },
      userId,
      request: req
    });
  });

  next();
}
