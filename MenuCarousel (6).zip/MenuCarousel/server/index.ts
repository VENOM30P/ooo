import express, { type Request, Response, NextFunction } from "express";
import cookieParser from "cookie-parser";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { initializeDatabase } from "./db";
import { dbCircuitBreaker } from "./utils/circuitBreaker";
import { dbHealthCheck } from "./utils/healthCheck";

const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

// Endpoint de health check para monitoramento
app.get("/api/health", async (_req: Request, res: Response) => {
  try {
    const isHealthy = await dbHealthCheck.checkDatabaseHealth();

    if (isHealthy) {
      return res.status(200).json({
        status: "healthy",
        database: "connected",
        circuitBreaker: dbCircuitBreaker.getState()
      });
    } else {
      return res.status(503).json({
        status: "unhealthy",
        database: "disconnected",
        circuitBreaker: dbCircuitBreaker.getState()
      });
    }
  } catch (error) {
    console.error("Erro ao verificar saúde:", error);

    return res.status(500).json({
      status: "error",
      message: "Erro ao verificar saúde",
      details: error instanceof Error ? error.message : String(error)
    });
  }
});

(async () => {
  // Função para monitorar a saúde do banco de dados usando o novo sistema
  const startEnhancedHealthCheck = () => {
    // Use o health check que implementamos
    dbHealthCheck.startMonitoring();
    console.log('Sistema de monitoramento de saúde aprimorado iniciado');
  };

  // Initialize database
  try {
    await initializeDatabase();
    log("Database initialized successfully");

    // Inicia o monitoramento de saúde do banco de dados
    startEnhancedHealthCheck();
  } catch (error) {
    console.error("Failed to initialize database:", error);
    process.exit(1);
  }

  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`Servidor rodando em http://0.0.0.0:${port}`);
  }).on('error', (error) => {
    console.error('Erro no servidor:', error);
    // Tentar reconectar em caso de erro
    setTimeout(() => {
      server.listen(port);
    }, 3000);
  }).on('close', () => {
    log('Conexão do servidor fechada. Tentando reconectar...');
    setTimeout(() => {
      server.listen(port);
    }, 3000);
  });
})();