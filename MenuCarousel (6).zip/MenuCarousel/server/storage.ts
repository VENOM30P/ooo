import { 
  Product, InsertProduct, 
  CartItem, InsertCartItem,
  MotivationalSlide, InsertMotivationalSlide,
  StorySlide, InsertStorySlide,
  User, InsertUser,
  products,
  users,
  cartItems,
  motivationalSlides,
  storySlides
} from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // User Methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getAllUsers(): Promise<User[]>;
  promoteUser(id: number): Promise<User | undefined>;
  deleteUser(id: number): Promise<boolean>;

  // Product Methods
  getProducts(): Promise<Product[]>;
  getProductById(id: number): Promise<Product | undefined>;
  getPromotedProducts(): Promise<Product[]>;
  getBestSellerProducts(): Promise<Product[]>;
  createProduct(product: InsertProduct): Promise<Product>;
  updateProduct(id: number, product: InsertProduct): Promise<Product | undefined>;
  deleteProduct(id: number): Promise<boolean>;

  // Cart Methods
  getCartItems(sessionId: string): Promise<CartItem[]>;
  getCartItemById(id: number): Promise<CartItem | undefined>;
  createCartItem(cartItem: InsertCartItem): Promise<CartItem>;
  updateCartItemQuantity(id: number, quantity: number): Promise<CartItem | undefined>;
  deleteCartItem(id: number): Promise<boolean>;

  // Slide Methods
  getMotivationalSlides(): Promise<MotivationalSlide[]>;
  createMotivationalSlide(slide: InsertMotivationalSlide): Promise<MotivationalSlide>;
  getStorySlides(): Promise<StorySlide[]>;
  createStorySlide(slide: InsertStorySlide): Promise<StorySlide>;
}

export class DatabaseStorage implements IStorage {
  // User Methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  async getAllUsers(): Promise<User[]> {
    return await db.select().from(users);
  }

  async promoteUser(id: number): Promise<User | undefined> {
    const [user] = await db
      .update(users)
      .set({ isAdmin: true })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async deleteUser(id: number): Promise<boolean> {
    const result = await db.delete(users).where(eq(users.id, id));
    return result.rowCount > 0;
  }

  // Product Methods
  async getProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async getProductById(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product;
  }

  async getPromotedProducts(): Promise<Product[]> {
    return await db.select().from(products).where(eq(products.isPromoted, true));
  }

  async getBestSellerProducts(): Promise<Product[]> {
    return await db.select().from(products).where(eq(products.isBestSeller, true));
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }

  async updateProduct(id: number, product: InsertProduct): Promise<Product | undefined> {
    const [updatedProduct] = await db
      .update(products)
      .set(product)
      .where(eq(products.id, id))
      .returning();
    return updatedProduct;
  }

  async deleteProduct(id: number): Promise<boolean> {
    const result = await db.delete(products).where(eq(products.id, id));
    return result.rowCount > 0;
  }

  // Cart Methods
  async getCartItems(sessionId: string): Promise<CartItem[]> {
    return await db.select().from(cartItems).where(eq(cartItems.sessionId, sessionId));
  }

  async getCartItemById(id: number): Promise<CartItem | undefined> {
    const [item] = await db.select().from(cartItems).where(eq(cartItems.id, id));
    return item;
  }

  async createCartItem(cartItem: InsertCartItem): Promise<CartItem> {
    const [newItem] = await db.insert(cartItems).values(cartItem).returning();
    return newItem;
  }

  async updateCartItemQuantity(id: number, quantity: number): Promise<CartItem | undefined> {
    const [updatedItem] = await db
      .update(cartItems)
      .set({ quantity })
      .where(eq(cartItems.id, id))
      .returning();
    return updatedItem;
  }

  async deleteCartItem(id: number): Promise<boolean> {
    const result = await db.delete(cartItems).where(eq(cartItems.id, id));
    return result.rowCount > 0;
  }

  // Slide Methods
  async getMotivationalSlides(): Promise<MotivationalSlide[]> {
    return await db.select().from(motivationalSlides);
  }

  async createMotivationalSlide(slide: InsertMotivationalSlide): Promise<MotivationalSlide> {
    const [newSlide] = await db.insert(motivationalSlides).values(slide).returning();
    return newSlide;
  }

  async getStorySlides(): Promise<StorySlide[]> {
    return await db.select().from(storySlides);
  }

  async createStorySlide(slide: InsertStorySlide): Promise<StorySlide> {
    const [newSlide] = await db.insert(storySlides).values(slide).returning();
    return newSlide;
  }
}

export const storage = new DatabaseStorage();