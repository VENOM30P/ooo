import { db, registerDatabaseReadyCallback, reconnectDatabase } from "../db";
import { logs, type InsertLog } from "@shared/schema";
import type { Request } from "express";
import { sql } from "drizzle-orm";

export type LogLevel = 'info' | 'warn' | 'error';
export type LogCategory = 'auth' | 'product' | 'user' | 'cart' | 'system';

// Flag para controlar se o banco de dados está pronto
let isDatabaseReady = false;

interface LogOptions {
  level?: LogLevel;
  category: LogCategory;
  message: string;
  details?: any;
  userId?: number;
  request?: Request;
}

class Logger {
  // Flag para controlar tentativas de reconexão simultâneas
  private isReconnecting = false;

  async log({
    level = 'info',
    category,
    message,
    details,
    userId,
    request
  }: LogOptions): Promise<void> {
    // Sempre imprimir no console de qualquer forma
    const timestamp = new Date().toISOString();
    console.log(`[${timestamp}] [${level.toUpperCase()}] [${category}]: ${message}`);
    if (details) {
      console.log('Details:', details);
    }
    
    // Se o banco de dados não estiver pronto, não tente salvar no banco
    if (!isDatabaseReady) {
      return;
    }
    
    try {
      const logEntry: InsertLog = {
        level,
        category,
        message,
        details: details ? JSON.stringify(details) : null,
        userId: userId || null,
        ipAddress: request?.ip || null,
        userAgent: request?.headers['user-agent'] || null,
        path: request?.path || null,
      };

      await db.insert(logs).values(logEntry);
    } catch (error) {
      console.error('Erro ao salvar log:', error);
      
      // Verifica se é um erro de conexão
      const isConnectionError = error instanceof Error && (
        error.message.includes('Connection terminated') || 
        error.message.includes('Connection error') ||
        error.message.includes('connection') ||
        error.message.includes('timeout')
      );
      
      if (isConnectionError) {
        isDatabaseReady = false;
        console.warn('Conexão com o banco de dados perdida. Tentando reconectar...');
        
        // Inicia o processo de reconexão em background
        this.handleReconnection();
      }
    }
  }
  
  // Método separado para gerenciar o processo de reconexão
  private async handleReconnection(): Promise<void> {
    try {
      // Evita múltiplas tentativas de reconexão simultâneas
      if (this.isReconnecting) return;
      this.isReconnecting = true;
      
      console.log('Iniciando processo de reconexão do banco de dados...');
      
      // Atraso antes da primeira tentativa para evitar reconexão imediata
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Tenta reconectar com a lógica de retentativas
      const reconnected = await reconnectDatabase(7, 5000);
      
      if (reconnected) {
        isDatabaseReady = true;
        console.log('Reconexão bem-sucedida. Logger voltou a funcionar.');
        
        // Testa se a conexão está realmente funcionando
        try {
          await db.execute(sql`SELECT 1`);
          console.log('Teste de conexão bem-sucedido após reconexão');
        } catch (testError) {
          console.error('Teste de conexão falhou após reconexão:', testError);
          isDatabaseReady = false;
          // Agenda uma nova tentativa após um intervalo maior
          setTimeout(() => {
            this.isReconnecting = false;
            this.handleReconnection();
          }, 60000); // Tenta novamente após 1 minuto
          return;
        }
      } else {
        console.error('Falha na reconexão. Logs continuarão apenas no console.');
        
        // Agenda uma nova tentativa após um intervalo
        setTimeout(() => {
          this.isReconnecting = false;
          this.handleReconnection();
        }, 60000); // Tenta novamente após 1 minuto
      }
    } catch (error) {
      console.error('Erro durante o processo de reconexão:', error);
      
      // Agenda uma nova tentativa mesmo após erro
      setTimeout(() => {
        this.isReconnecting = false;
        this.handleReconnection();
      }, 60000); // Tenta novamente após 1 minuto
    } finally {
      this.isReconnecting = false;
    }
  }
  
  // Método para sinalizar que o banco de dados está pronto
  setDatabaseReady(): void {
    isDatabaseReady = true;
    console.log('Logger: Banco de dados está pronto para logs');
  }

  info(options: Omit<LogOptions, 'level'>): Promise<void> {
    return this.log({ ...options, level: 'info' });
  }

  warn(options: Omit<LogOptions, 'level'>): Promise<void> {
    return this.log({ ...options, level: 'warn' });
  }

  error(options: Omit<LogOptions, 'level'>): Promise<void> {
    return this.log({ ...options, level: 'error' });
  }
}

export const logger = new Logger();
export const setDatabaseReady = () => logger.setDatabaseReady();

// Registra o callback para quando o banco de dados estiver pronto
registerDatabaseReadyCallback(() => {
  logger.setDatabaseReady();
});
