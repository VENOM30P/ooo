import { pool, reconnectDatabase } from "../db";
import { dbCircuitBreaker } from "./circuitBreaker";
import { logger } from "./logger";

/**
 * Classe para gerenciar a verificação de saúde do banco de dados
 */
export class DatabaseHealthCheck {
  private intervalId: NodeJS.Timeout | null = null;
  private readonly checkInterval: number;
  private consecutiveFailures: number = 0;
  private isCheckingHealth: boolean = false;
  
  constructor(checkIntervalMs = 30000) {
    this.checkInterval = checkIntervalMs;
  }
  
  /**
   * Inicia o monitoramento periódico de saúde da conexão com o banco de dados
   */
  startMonitoring(): void {
    if (this.intervalId) {
      return; // Já está monitorando
    }
    
    console.log(`Iniciando monitoramento de saúde do banco de dados a cada ${this.checkInterval/1000}s`);
    
    // Executa uma verificação imediata
    this.checkDatabaseHealth();
    
    // Configura verificações periódicas
    this.intervalId = setInterval(() => {
      this.checkDatabaseHealth();
    }, this.checkInterval);
  }
  
  /**
   * Para o monitoramento periódico
   */
  stopMonitoring(): void {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
      console.log('Monitoramento de saúde do banco de dados parado');
    }
  }
  
  /**
   * Verifica a saúde atual da conexão com o banco de dados
   */
  async checkDatabaseHealth(): Promise<boolean> {
    // Evita várias verificações simultâneas
    if (this.isCheckingHealth) {
      return true;
    }
    
    this.isCheckingHealth = true;
    
    try {
      if (dbCircuitBreaker.isOpen()) {
        this.isCheckingHealth = false;
        return false;
      }
      
      const result = await dbCircuitBreaker.execute(async () => {
        const client = await pool.connect();
        try {
          const result = await client.query('SELECT 1 as connected');
          return result.rows[0].connected === 1;
        } finally {
          client.release();
        }
      });
      
      if (result) {
        console.log('Verificação de saúde: Banco de dados está operacional');
        this.consecutiveFailures = 0;
        return true;
      } else {
        throw new Error('Resultado inesperado da consulta de verificação de saúde');
      }
    } catch (error) {
      this.consecutiveFailures++;
      console.error(`Erro na verificação de saúde do banco de dados (falha ${this.consecutiveFailures}):`, error);
      
      // Se tivermos múltiplas falhas consecutivas, tenta reconectar
      if (this.consecutiveFailures >= 3) {
        console.warn(`${this.consecutiveFailures} falhas consecutivas na verificação de saúde. Tentando reconectar...`);
        try {
          await reconnectDatabase();
          // Reset contador se reconexão funcionar
          this.consecutiveFailures = 0; 
        } catch (reconnectError) {
          console.error('Falha na tentativa de reconexão durante verificação de saúde:', reconnectError);
        }
      }
      
      return false;
    } finally {
      this.isCheckingHealth = false;
    }
  }
  
  /**
   * Retorna o estado atual do monitoramento
   */
  isMonitoring(): boolean {
    return this.intervalId !== null;
  }
}

// Singleton para uso em toda a aplicação
export const dbHealthCheck = new DatabaseHealthCheck(60000); // Verificar a cada 1 minuto