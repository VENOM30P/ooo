/**
 * Um padrão de Circuit Breaker simples para proteger a aplicação contra falhas de banco de dados
 * 
 * O Circuit Breaker previne tentativas excessivas de conexão quando o serviço externo está com problemas.
 * Funciona em três estados:
 * - CLOSED: Estado normal, permite que as operações sejam executadas
 * - OPEN: Estado de falha, rejeita todas as operações sem tentar executá-las
 * - HALF_OPEN: Estado de teste, permite que algumas operações sejam executadas para verificar recuperação
 */

enum CircuitState {
  CLOSED = 'CLOSED',
  OPEN = 'OPEN', 
  HALF_OPEN = 'HALF_OPEN'
}

export class CircuitBreaker {
  private state: CircuitState = CircuitState.CLOSED;
  private failureCount: number = 0;
  private successCount: number = 0;
  private lastFailureTime: number = 0;
  private readonly failureThreshold: number;
  private readonly resetTimeout: number;
  private readonly successThreshold: number;
  
  constructor(
    failureThreshold: number = 5,
    resetTimeout: number = 30000,
    successThreshold: number = 2
  ) {
    this.failureThreshold = failureThreshold;
    this.resetTimeout = resetTimeout;
    this.successThreshold = successThreshold;
  }
  
  /**
   * Executa uma operação através do circuit breaker
   * @param operation A função a ser executada
   * @returns O resultado da operação ou uma exceção
   */
  async execute<T>(operation: () => Promise<T>): Promise<T> {
    if (this.isOpen()) {
      const timeInOpen = Date.now() - this.lastFailureTime;
      
      if (timeInOpen >= this.resetTimeout) {
        this.state = CircuitState.HALF_OPEN;
        console.log(`Circuito passando para meio-aberto após ${timeInOpen}ms`);
      } else {
        throw new Error(`Circuito aberto, recusando operação (${Math.round(this.resetTimeout - timeInOpen)/1000}s restantes para nova tentativa)`);
      }
    }
    
    try {
      const result = await operation();
      
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }
  
  /**
   * Verifica se o circuito está no estado aberto (não permite operações)
   */
  isOpen(): boolean {
    return this.state === CircuitState.OPEN;
  }
  
  /**
   * Registra uma operação bem-sucedida
   */
  private onSuccess(): void {
    if (this.state === CircuitState.HALF_OPEN) {
      this.successCount++;
      
      if (this.successCount >= this.successThreshold) {
        this.reset();
        console.log('Circuito fechado depois de operações bem-sucedidas');
      }
    }
  }
  
  /**
   * Registra uma falha na operação
   */
  private onFailure(): void {
    this.lastFailureTime = Date.now();
    
    if (this.state === CircuitState.HALF_OPEN) {
      this.tripBreaker();
      return;
    }
    
    this.failureCount++;
    
    if (this.failureCount >= this.failureThreshold) {
      this.tripBreaker();
    }
  }
  
  /**
   * Abre o disjuntor, bloqueando todas as operações
   */
  private tripBreaker(): void {
    this.state = CircuitState.OPEN;
    console.log(`Circuito aberto após ${this.failureCount} falhas`);
  }
  
  /**
   * Reseta o estado do circuito para fechado (normal)
   */
  private reset(): void {
    this.failureCount = 0;
    this.successCount = 0;
    this.state = CircuitState.CLOSED;
  }
  
  /**
   * Força a abertura do circuito
   */
  public forceOpen(): void {
    this.state = CircuitState.OPEN;
    this.lastFailureTime = Date.now();
    console.log('Circuito forçado para aberto');
  }
  
  /**
   * Força o fechamento do circuito
   */
  public forceClose(): void {
    this.reset();
    console.log('Circuito forçado para fechado');
  }
  
  /**
   * Retorna o estado atual do circuito
   */
  public getState(): string {
    return this.state;
  }
}

// Singleton para uso em toda a aplicação
export const dbCircuitBreaker = new CircuitBreaker(3, 15000, 2);